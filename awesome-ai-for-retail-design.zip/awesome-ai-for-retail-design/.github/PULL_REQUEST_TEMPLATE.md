## What are you adding or changing?

- [ ] New tool
- [ ] New or improved prompt
- [ ] Case study
- [ ] Fix (typo, broken link, wording)

## Checklist

- [ ] I have used this tool/prompt myself, or can clearly verify it
- [ ] The link works
- [ ] I followed the format in CONTRIBUTING.md
- [ ] AI-generated images are labelled and I have rights to share them
