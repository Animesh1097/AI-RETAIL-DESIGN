# VM audit checklist

Score each item: 2 = good, 1 = needs work, 0 = missing or poor. Add notes and photos.

| Area | Check | Score | Notes |
|---|---|---|---|
| Facade and window | Clear idea, readable at a glance | | |
| | Clean, lit day and night, no glare | | |
| | Hero product and offer visible | | |
| Entrance | Open, clean, welcoming first 2 to 3 m | | |
| | No clutter or sale bins in the way | | |
| Layout | Clear main route, no dead ends | | |
| | Hero display visible from the door | | |
| | Aisles comfortable and accessible | | |
| Displays | Clear hierarchy: hero, support, fill | | |
| | Colour blocking and rhythm | | |
| | Best sellers at eye and hand level | | |
| | Fully stocked, tidy, faced forward | | |
| Cross-merchandising | Related products shown together | | |
| Signage | Clear hierarchy, readable, on brand | | |
| | Prices clear and correct | | |
| Lighting | Hero items lit, no dark spots or glare | | |
| | Consistent colour temperature | | |
| Cash wrap | Tidy, visible, queue space | | |
| | Add-on items relevant | | |
| Fitting or demo areas | Clean, lit, private where needed | | |
| Cleanliness | Floors, glass, fixtures clean | | |
| Maintenance | No broken lights, damaged fixtures, peeling graphics | | |
| Staff and service | Visible, approachable | | |

**Total:** / 52 · **Top three fixes:** 1. 2. 3.
