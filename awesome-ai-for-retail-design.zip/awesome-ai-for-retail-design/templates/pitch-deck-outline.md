# Pitch deck outline

| # | Slide | Content |
|---|---|---|
| 1 | Title | Project, client, date |
| 2 | Brief in one page | Objectives, audience, constraints |
| 3 | Insight | What you learned from customers and competitors |
| 4 | Concept | The big idea in one sentence, with a hero image |
| 5 | Design pillars | Three pillars, each with a design move |
| 6 | Layout | Plan with flow and zones |
| 7 | Hero view | Entrance or feature view, labelled AI-assisted |
| 8 | Experience | Journey: approach to purchase |
| 9 | Materials and light | Palette, key materials, lighting layers |
| 10 | Merchandising | Windows, key displays, signage approach |
| 11 | Programme and budget | Phases, key dates, indicative cost range |
| 12 | Next steps | Decisions needed and timeline |
| Appendix | Alternative concept, further views, risks | |

Notes: one idea per slide, large images, short text, a visible label on every AI-assisted image.
