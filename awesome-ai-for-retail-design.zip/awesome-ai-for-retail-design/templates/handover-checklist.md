# Handover checklist

| Item | Responsible | Status |
|---|---|---|
| Final as-built drawings | Contractor | |
| Test certificates (electrical, fire, HVAC) | Contractor | |
| Warranties and guarantees | Contractor and vendors | |
| Operation and maintenance manuals | Contractor | |
| Keys, access cards, alarm codes | Contractor | |
| Fixture and furniture inventory | Designer | |
| Material and paint codes for repairs | Designer | |
| Spare parts and spare finishes | Contractor | |
| Lighting scenes programmed and documented | Lighting designer | |
| Signage installed and approved | Signage vendor | |
| Critical snags closed | Contractor | |
| Remaining snags with dates | Contractor | |
| VM guide and opening displays | Designer and VM team | |
| Staff walk-through | Client | |
| Final photos | Photographer or designer | |
| Sign-off | Client | |
