# Design brief

**Project:** · **Client:** · **Date:** · **Version:**

## 1. Overview
What is being designed, where, for whom, and why.

## 2. Objectives
- Business objective:
- Customer experience objective:
- Brand objective:

## 3. Audience
Who they are, why they visit, how long they stay.

## 4. Brand personality
Three words, and what each one means in physical terms (material, light, layout).

## 5. Range and display needs
Categories, hero products, sizes, special requirements.

## 6. Space
Area, frontage, ceiling height, services, constraints, landlord rules.

## 7. Operations
Staffing, services, stock, cash wrap, security.

## 8. Must-haves and no-gos

## 9. Budget and programme
| Item | Detail |
|---|---|
| Budget | |
| Design deadline | |
| Opening date | |
| Approval steps | |

## 10. References
Stores, images, materials liked and disliked (with reasons).

## 11. Deliverables

## 12. Success measures

## 13. Open questions (TO CONFIRM)
