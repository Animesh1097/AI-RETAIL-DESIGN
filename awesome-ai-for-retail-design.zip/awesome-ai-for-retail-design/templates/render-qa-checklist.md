# Render QA checklist

**Image:** · **Tool and settings:** · **Reviewer:** · **Date:**

| Area | Check | Pass | Note |
|---|---|---|---|
| Layout | Positions match the plan | ☐ | |
| Scale | Doors, counters, shelves look right | ☐ | |
| Structure | Columns, beams, walls are logical | ☐ | |
| Fixtures | Can be built, fixed, and serviced | ☐ | |
| Materials | Match the material schedule | ☐ | |
| Lighting | Sources and shadows make sense | ☐ | |
| Reflections | Glass and mirrors behave | ☐ | |
| Products | Accurate, not misleading | ☐ | |
| Text and logos | Correct, not copied from another brand | ☐ | |
| People and props | None unintended | ☐ | |
| Accessibility | Routes and heights plausible | ☐ | |
| Safety | Exits visible and clear | ☐ | |
| Consistency | Matches other views in the set | ☐ | |
| Artefacts | No smears, merged objects, odd textures | ☐ | |
| Labelling | "AI-assisted visual" noted | ☐ | |
| Rights | Tool terms allow this use | ☐ | |

**Decision:** Approved / Fix and recheck / Reject
