# Project timeline

Fill in durations with your own experience and the client's constraints.

| Phase | Key tasks | Owner | Start | End | Dependencies |
|---|---|---|---|---|---|
| Brief | Questionnaire, brief sign-off | | | | |
| Concept | Mood, narrative, layout options | | | | Brief |
| Design development | Materials, lighting, fixtures, 3D views | | | | Concept approval |
| Documentation | Drawings, BOQ, specs | | | | Design approval |
| Tender and procurement | RFQs, quotes, orders | | | | Documentation |
| Fit-out | Construction, fixtures, signage | | | | Orders, site access |
| Snagging | Inspection, fixes | | | | Fit-out |
| Handover and VM | Final checks, opening displays | | | | Snags |
| Opening and content | Photos, reels, case study | | | | Handover |

Add critical dates: landlord approvals, long-lead items, opening date.
