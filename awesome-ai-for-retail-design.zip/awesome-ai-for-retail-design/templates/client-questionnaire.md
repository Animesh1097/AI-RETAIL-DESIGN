# Client questionnaire

Use at the first meeting. Skip what the client has already answered in writing.

## 1. Business and goals
1. What is the purpose of this store (sales, brand awareness, experience, testing a market)?
2. What does success look like in 12 months?
3. Is this a new store, a refresh, or a relocation?
4. Are more stores planned? Should this design be a prototype for a rollout?
5. Which numbers matter most to you (sales, conversion, average spend, footfall)?

## 2. Customer
6. Who is the main customer? Age, lifestyle, spending habits.
7. Why do they visit: planned purchase, gift, browsing, service?
8. How long do they usually stay?
9. What frustrates customers in your current stores or competitors?
10. Do customers come alone, in pairs, or with family?

## 3. Product and range
11. What categories and approximate number of products?
12. Which products are heroes (best sellers, high margin, new)?
13. Size and weight of the biggest and smallest items?
14. How often does the range change? Seasonal drops?
15. Any items needing security, special lighting, or demonstration?

## 4. Brand
16. Three words that describe the brand.
17. Brand guidelines available? (Colours, fonts, materials, tone.)
18. Existing stores or references you like and dislike? Why?
19. Anything you never want to see in the store?
20. How do you want customers to describe the store to a friend?

## 5. Space and site
21. Location, street or mall, and the landlord's design criteria?
22. Area, frontage, ceiling height, and drawings available?
23. Existing services: electrical, HVAC, plumbing, fire systems?
24. Constraints: columns, level changes, signage restrictions, loading hours?
25. Neighbouring units and footfall direction?

## 6. Operations
26. Number of staff on the floor at peak?
27. Services: fitting rooms, consultations, demos, repairs, click and collect?
28. Stock volume to hold on site? Replenishment frequency?
29. Payment and queue needs? Number of tills?
30. Security, CCTV, and anti-theft requirements?

## 7. Budget and time
31. Budget range, and what it includes (design, build, fixtures, lighting, signage, IT)?
32. Target opening date and any fixed dates?
33. Who approves design, budget, and changes?
34. How involved do you want to be in decisions?

## 8. Marketing and content
35. Do you need photos, reels, or case-study content from the project?
36. Opening event or campaign planned?
37. Social media style and channels?

## 9. Risk and legal
38. Are there permits or approvals needed (fire, municipal, landlord)?
39. Any health or safety standards for your category?
40. Are you comfortable with AI-assisted concept visuals? Any confidentiality rules?

## Notes and follow-ups

| Topic | Answer | Follow-up | Owner | Date |
|---|---|---|---|---|
| | | | | |
