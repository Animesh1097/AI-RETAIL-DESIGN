# Video and social

Turn store visuals into reels and posts. Reviewed October 2026.

| Tool | Good for | Watch out for |
|---|---|---|
| [Runway](https://runwayml.com) ([profile](profiles/runway.md)) | Image-to-video, video editing, access to several video models | Credit use; check terms |
| [Kling](https://klingai.com) ([profile](profiles/kling.md)) | Image-to-video with audio, multi-shot | Check commercial terms and data location |
| [Pika](https://pika.art) | Short clips and effects | Quality varies by scene |
| [Luma](https://lumalabs.ai) | Camera moves from stills, 3D capture | Check current models and terms |
| [CapCut](https://www.capcut.com) | Quick editing, captions | Check licences for built-in music |
| [Descript](https://www.descript.com) | Edit by text, clean voiceover | Not an effects tool |
| [ElevenLabs](https://elevenlabs.io) | Voiceover | Voice cloning needs written consent |
| [HeyGen](https://www.heygen.com) | AI presenter videos | Disclose AI presenters where required |
| [Suno](https://suno.com) | AI music | Check the licence for commercial use |

Guide: [AI video for retail](../guides/11-ai-video-for-retail.md) · Workflow: [Store reel in a day](../workflows/store-reel-in-a-day.md)
