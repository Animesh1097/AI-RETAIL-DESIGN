# Maket

**Type:** AI floor plan generator · **Cost model:** Free tier plus paid plans · **Reviewed:** October 2026

## What it is

A tool that generates and edits floor plans through a guided chat, or from drawing and uploading an existing plan. It is **built mainly for residential** plans, and its own materials say no AI floor-plan tool produces drawings that building departments accept for permit review.

## Good for retail design

- Seeing how an AI proposes room relationships, as a thinking aid
- Quick massing of small mixed-use spaces such as a home studio with a shopfront
- Converting a plan image into something editable (paid feature)

## Limits

- Not designed for retail circulation, fixtures, or cash wraps
- Outputs need verification for dimensions, structure, and codes
- Commercial and mixed-use support is limited

## Better path for retail

Use an assistant for the [space programme and adjacency](../../prompts/planning/zoning-and-flow-options.md), draw options yourself, and score them with the [layout matrix](../../guides/02-store-planning-and-customer-flow.md#score-your-layout-options).

## Alternatives

See [Layout and floor plans](../layout-and-floorplans.md).
