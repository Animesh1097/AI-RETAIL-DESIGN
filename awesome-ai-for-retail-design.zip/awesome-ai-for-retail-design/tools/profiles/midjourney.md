# Midjourney

**Type:** Image and image-to-video generator · **Access:** Web app and Discord · **Cost model:** Subscription · **Reviewed:** October 2026

## What it is

An AI image generator known for strong aesthetics and atmosphere. In 2026 it is on its V8 family of models, with style references, an omni/object reference feature, personalisation, a fast draft mode, and image-to-video (it animates an image rather than generating video from text alone). Versions and features change quickly, so check the current docs.

## Good for retail design

- Concept and mood exploration for store themes, windows, and campaigns
- Material and lighting atmosphere studies
- Consistent looks across a series using the same style reference
- Quick "what if" variations for pitch discussions

## Limits

- Limited control over exact layouts and dimensions
- Text and fine details are better than before but still need checking
- Not a drawing tool: scale, structure, and buildability are your job
- Reportedly no free trial, so budget for a subscription
- Legal disputes about training data were reported as unresolved in 2026. Consider this for client-facing final assets.

## Tips

1. Write prompts with the [anatomy in the prompting guide](../../guides/07-prompting-for-retail-visuals.md).
2. Use `--ar 16:9` (or your needed ratio) for wide views.
3. Use an approved image as a **style reference** to keep a set consistent.
4. Explore wide in draft mode, then re-run the winner at full quality.
5. Fix text, logos, and details in an editor.

## Starter workflow

Mood board prompt → pick 2 directions → lock a spec block → generate 5 views with a shared style reference → label as AI concepts.

## Licensing and data

Read the current terms for commercial use, and for how prompts and images are stored. Don't upload confidential plans. For final assets with legal sensitivity, consider tools that offer indemnification (see [Firefly](adobe-firefly.md)) or create the final art by hand.

## Alternatives

[Adobe Firefly](adobe-firefly.md), Krea, Leonardo, ChatGPT or Gemini image generation.
