# AI assistants (Claude, ChatGPT, Gemini)

**Type:** General AI assistants · **Reviewed:** October 2026

## What they are

Chat assistants that read and write text, work with uploaded documents and images, and can produce tables, spreadsheets, and structured outputs. For retail design they are your **drafting and structuring partner**, not an authority on facts or measurements.

## Good for retail design

- Turning client notes into a structured brief and a list of questions
- Drafting concept narratives, specifications, and emails
- Building BOQ skeletons, finish schedules, and checklists
- Minutes into action lists, snag lists, and handover documents
- Reel scripts, captions, and case-study write-ups
- Critiquing a plan you describe in text

## Limits

- They state wrong things confidently. Verify facts, ratings, availability, and prices.
- Reading drawings and counting items from images is unreliable.
- They don't know your client's politics or local code.
- Consumer plans may store or learn from your data. Check settings.

## Tips

1. Give context: store type, area, city, budget, brand tone, audience.
2. Ask for structure (tables, CSV) you can paste into a spreadsheet.
3. Ask the assistant to mark gaps as "TO CONFIRM" instead of guessing.
4. Keep reusable instructions (brand rules, house style) in a project or custom-instructions feature where available.
5. Save prompts that work in the [prompt log](../../templates/prompt-log-template.csv).

## Starter prompts

[Client questionnaire](../../prompts/discovery/client-discovery-questions.md) · [Brief to design brief](../../prompts/discovery/brief-to-design-brief.md) · [BOQ skeleton](../../prompts/documentation/boq-skeleton.md) · [Minutes to actions](../../prompts/documentation/meeting-minutes-to-actions.md)
