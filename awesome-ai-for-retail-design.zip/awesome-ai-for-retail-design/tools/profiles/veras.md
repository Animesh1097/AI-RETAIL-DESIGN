# Veras

**Type:** AI rendering plug-in for CAD and BIM · **Access:** Plug-ins for Revit, SketchUp, Rhino, Archicad, Vectorworks, plus a web version · **Cost model:** Subscription, with a trial · **Reviewed:** October 2026

## What it is

Developed by EvolveLAB and now part of Chaos (the company behind V-Ray and Enscape). Veras reads the view from your 3D model and restyles it with AI, so the render follows the geometry you modelled. Sliders control how strongly it follows the geometry and how closely it follows your text prompt.

## Good for retail design

- Turning a SketchUp or Rhino store model into fast, styled visuals
- Testing material and lighting alternatives without re-modelling
- Keeping the image tied to the same model that produces your drawings

## Limits

- It is still AI, and may add or change details, glazing, and small items. Always compare with the model.
- Output resolution and features depend on version and plan.
- You need a decent 3D model first.

## Tips

1. Clean your model view: simple materials, clear camera, no clutter.
2. Raise the geometry strength when the layout must stay exact.
3. Describe materials and lighting in the prompt; don't repeat geometry.
4. Save presets for each project so views stay consistent.

## Starter workflow

Model the store → set a camera → run Veras with a spec-block prompt → compare with the model → upscale the chosen render → present with drawings.

## Alternatives

[mnml.ai](mnml-ai.md), [ComfyUI](comfyui.md), D5 Render for conventional real-time rendering.
