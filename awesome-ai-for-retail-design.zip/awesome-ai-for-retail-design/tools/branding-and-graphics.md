# Branding and graphics

Signage, POP material, logos, and brand assets. Reviewed October 2026.

| Tool | Good for | Watch out for |
|---|---|---|
| [Canva](https://www.canva.com) ([profile](profiles/canva.md)) | Fast layouts, templates, brand kits for small teams | Not a substitute for print-ready vector files |
| [Figma](https://www.figma.com) | Design systems and handoff, with plugins | Learning curve for non-designers |
| [Adobe Illustrator](https://www.adobe.com/products/illustrator.html) | Vector artwork and signage files | Check AI features and credits on your plan |
| [Recraft](https://www.recraft.ai) | Vector-style graphics, icons, illustrations | Review for originality |
| [Ideogram](https://ideogram.ai) | Poster and signage mockups with text | Proofread every character |
| [Looka](https://looka.com) | Logo and brand kit starting points | Many results look generic; check originality |

## Signage workflow

1. Write the message (max 6 words) with an assistant ([prompt](../prompts/merchandising/signage-and-wayfinding.md)).
2. Mock up options with an image tool.
3. Rebuild the winner as **vector artwork** with real fonts.
4. Send dimensioned artwork to the fabricator.
5. Check a physical sample.
