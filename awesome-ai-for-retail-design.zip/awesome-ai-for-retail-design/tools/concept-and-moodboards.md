# Concept and mood boards

Use these to explore ideas before you draw. Reviewed October 2026.

| Tool | Good for | Watch out for |
|---|---|---|
| [Midjourney](https://www.midjourney.com) ([profile](profiles/midjourney.md)) | Atmosphere, materials mood, campaign imagery; style references for consistency | Weak control over exact layout; check commercial terms |
| [Adobe Firefly](https://firefly.adobe.com) ([profile](profiles/adobe-firefly.md)) | Mood boards (Firefly Boards), generative edits in Photoshop, brand-safe positioning | Partner models and beta features may not have the same coverage |
| [Krea](https://www.krea.ai) | Fast exploration and image enhancement | Check current features and terms |
| [Ideogram](https://ideogram.ai) | Text inside images, posters, signage ideas | Always proofread the lettering |
| [Leonardo](https://leonardo.ai) | Style and reference controls | Check terms for commercial use |
| [ChatGPT](https://chatgpt.com) / [Gemini](https://gemini.google.com) | Image generation inside a chat; iterating by conversation | Less control over fine detail |

## How to run a concept round

1. Write the brief in 5 lines ([template](../templates/design-brief-template.md)).
2. Use the [mood board prompt](../prompts/concept/concept-moodboard.md) with 4 style lines.
3. Choose 2 directions, and write the spec block ([guide](../guides/09-keeping-renders-consistent.md)).
4. Convert the chosen visuals into a one-page concept statement ([prompt](../prompts/concept/concept-narrative.md)).
5. Label AI images in the board.
