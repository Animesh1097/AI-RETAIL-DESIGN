# Layout and floor plans

Honest summary: **most AI floor-plan tools are built for homes or offices, not shops.** Use them to spark ideas, then plan and draw the real retail layout in CAD. Reviewed October 2026.

| Tool | What it does | Retail relevance |
|---|---|---|
| [Maket](https://www.maket.ai) ([profile](profiles/maket.md)) | Generates and edits residential floor plans through chat | Low. Useful to see how room relationships get proposed |
| [Planner 5D](https://planner5d.com) | Drag-and-drop planning with AI-assisted features such as auto-furnishing | Medium for quick client walk-throughs |
| [Coohom](https://www.coohom.com) | Interior design and rendering platform | Medium for fit-out visuals |
| [Foyr](https://foyr.com) | Interior design and rendering | Medium for presentation visuals |
| [Finch](https://www.finch3d.com) | Layout generation and optimisation, strongest on multi-unit residential | Low for shops |
| [Autodesk Forma](https://www.autodesk.com/products/forma) | Early-stage planning and analysis for buildings and sites | Medium for large projects and mall planning |
| [RoomSketcher](https://www.roomsketcher.com) | Floor plan drawing with AI conversion of sketches and photos | Medium for digitising existing plans |

## A better approach for retail

1. Create the **space programme** and adjacency list with an assistant ([prompt](../prompts/planning/zoning-and-flow-options.md)).
2. Draw 3 to 5 layout options yourself in CAD or on paper.
3. Score the options with the [layout matrix](../guides/02-store-planning-and-customer-flow.md#score-your-layout-options).
4. Ask an assistant to critique your described plan.
5. Finalise with real dimensions, services, and codes.

Notes:
- No AI floor-plan generator replaces dimensioned drawings that authorities accept.
- Treat any area numbers from AI as unverified.
