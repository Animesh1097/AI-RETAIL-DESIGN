# Visual merchandising

Create product visuals, display mockups, and campaign backgrounds. Reviewed October 2026.

| Tool | Good for | Watch out for |
|---|---|---|
| [Photoroom](https://www.photoroom.com) ([profile](profiles/photoroom.md)) | Cutouts, backgrounds, batch edits across many product photos | AI scenes use credits; check product accuracy |
| [Pebblely](https://pebblely.com) ([profile](profiles/pebblely-and-flair.md)) | Simple upload-to-scene lifestyle backgrounds | Limited control of composition |
| [Flair](https://flair.ai) ([profile](profiles/pebblely-and-flair.md)) | Arranging props and scenes on a canvas before generating | More setup; credits |
| [Photoshop Generative Fill](https://www.adobe.com/products/photoshop.html) | Retouching, extending, replacing backgrounds | Keep real product detail intact |
| [Canva](https://www.canva.com) ([profile](profiles/canva.md)) | Shelf talkers, POP, in-store graphics | Final print files need checking |
| [Midjourney](https://www.midjourney.com) | Window and display concept imagery | Concepts must still be built physically |

## Rules for product visuals

1. The real product is the hero. Never let AI redraw logos, labels, or packaging.
2. Use one lighting direction across a set.
3. Keep a prop list with every approved display.
4. Check colour against the physical product.
5. Disclose AI-generated backgrounds where required by platform or client.

Prompts: [Window display](../prompts/merchandising/window-display.md) · [Product display backgrounds](../prompts/merchandising/product-display-backgrounds.md) · [Planogram brief](../prompts/merchandising/planogram-brief.md)
