# Tools

Tool landscape reviewed **October 2026**. Features, models, and pricing change often, so confirm on each vendor's site. Pages say what a tool is good for, where it falls short, and how to get good results in retail design work.

## Which tool for which job

| I want to... | Start with | Why | Alternatives |
|---|---|---|---|
| Explore store concepts and mood | [Midjourney](profiles/midjourney.md) | Strong atmosphere and aesthetic quality | [Firefly](profiles/adobe-firefly.md), Krea, Leonardo |
| Generate imagery with clearer commercial terms | [Adobe Firefly](profiles/adobe-firefly.md) | Enterprise indemnification options, Creative Cloud integration | Check each tool's terms |
| Render from my SketchUp, Rhino, or Revit model | [Veras](profiles/veras.md) | Works from your 3D geometry inside the CAD tool | mnml.ai, ComfyUI |
| Turn a sketch or screenshot into a render in the browser | [mnml.ai](profiles/mnml-ai.md) | Many architecture and interior tools in one place | Krea, ComfyUI |
| Get the most control and repeatability | [ComfyUI](profiles/comfyui.md) | Node-based control over structure and style | Veras |
| Explore floor plan ideas | [Maket](profiles/maket.md) (residential-first) | Fast layout ideation, but retail needs manual work | See [layout tools](layout-and-floorplans.md) |
| Make product and display visuals | [Photoroom](profiles/photoroom.md), [Pebblely and Flair](profiles/pebblely-and-flair.md) | Backgrounds, scenes, batch work | Photoshop Generative Fill |
| Design signage, posters, social graphics | [Canva](profiles/canva.md) | Fast layouts, templates, brand kits | Figma, Illustrator |
| Animate stills into video | [Runway](profiles/runway.md), [Kling](profiles/kling.md) | Image-to-video | Luma, Pika, Midjourney video |
| Write briefs, specs, BOQs, copy | [Assistants](profiles/assistants.md) | Structure and drafting | Any major assistant |

## Comparison

| Tool | Structure control | Ease | Cost model | Commercial clarity | Best retail use |
|---|---|---|---|---|---|
| Midjourney | Low to medium | Easy | Subscription | Check terms and current legal news | Concept and campaign imagery |
| Adobe Firefly | Medium | Easy | Subscription plus credits | Strongest for eligible enterprise plans | Brand-safe imagery, editing in Photoshop |
| Veras | High (uses your geometry) | Medium | Subscription or trial | Check terms | Renders from your own 3D model |
| mnml.ai | Medium | Easy | Credits or plans | Check terms | Quick sketch-to-render, upscaling |
| ComfyUI | Very high | Hard | Free software, hardware or cloud cost | Depends on each model's licence | Repeatable, layout-faithful pipelines |
| Maket | Not for retail | Easy | Free and paid tiers | Check terms | Early layout ideas (homes) |
| Photoroom | Not applicable | Very easy | Subscription plus credits | Check terms | Product cutouts and backgrounds |
| Runway | Medium | Medium | Credits | Paid plans include commercial use, check terms | Animating stills, editing |
| Kling | Medium | Easy | Credits | Check terms and data location | Short image-to-video clips |

## Starter stacks

**Solo designer (low cost):** one assistant + Canva + one image tool (Midjourney or Firefly) + CapCut.

**Studio or agency (client work):** an assistant on a business plan + Veras (or mnml.ai) with your 3D tool + Firefly for brand-safe assets + Photoshop + Runway for motion + a shared [prompt log](../templates/prompt-log-template.csv).

**Privacy-first:** a locally run ComfyUI with models whose licences allow your use + a local or enterprise assistant + no client data in consumer tools.

## Categories

- [Concept and mood boards](concept-and-moodboards.md)
- [Layout and floor plans](layout-and-floorplans.md)
- [3D and renders](3d-and-renders.md)
- [Visual merchandising](visual-merchandising.md)
- [Branding and graphics](branding-and-graphics.md)
- [Video and social](video-and-social.md)
- [Automation and assistants](automation-and-assistants.md)

## How tools are reviewed

A tool is included when it has a real use in retail design work, an official site, and clear current activity. Each profile separates what the vendor claims from practical limits. Tell us when something has changed. See [CONTRIBUTING](../CONTRIBUTING.md).
