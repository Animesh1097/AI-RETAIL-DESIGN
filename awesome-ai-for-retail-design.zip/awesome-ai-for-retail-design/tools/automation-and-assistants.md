# Automation and assistants

Use assistants for drafting and structure, and automation tools to repeat steps you already do the same way. Reviewed October 2026.

| Tool | Good for | Watch out for |
|---|---|---|
| [Claude](https://claude.ai), [ChatGPT](https://chatgpt.com), [Gemini](https://gemini.google.com) ([profile](profiles/assistants.md)) | Briefs, specs, BOQ skeletons, emails, minutes, copy | Verify every fact and number; protect confidential data |
| [n8n](https://n8n.io) | Visual workflow automation, self-hostable | Needs time to set up |
| [Make](https://www.make.com) | Visual automation between apps | Cost grows with operations |
| [Zapier](https://zapier.com) | Simple triggers between apps | Limited for complex flows |
| [Notion](https://www.notion.com) | Prompt libraries, trackers, project docs | Structure takes discipline |
| [Airtable](https://www.airtable.com) | Asset and content trackers | Set permissions carefully |

## Automate only what's stable

Good candidates: naming and filing assets, turning a form into a task list, sending status updates, collecting approvals. Poor candidates: design decisions, pricing, anything touching client contracts.
