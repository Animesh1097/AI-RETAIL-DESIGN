# 1. Retail design fundamentals

Read this first if you are new to retail design, or new to AI and want to know where it fits.

## What retail design is

Retail design shapes how a brand is experienced in a physical space so customers can find, understand, want, and buy products, and so staff can run the space efficiently. It sits where four disciplines meet:

| Discipline | Question it answers | Typical outputs |
|---|---|---|
| Brand and identity | Who are we, and how should the space feel? | Concept, brand guidelines, signage language |
| Spatial and interior design | How is the space organised and built? | Plans, elevations, 3D views, details |
| Visual merchandising (VM) | How is the product presented and sold? | Window and floor displays, planograms |
| Operations and commerce | Does it work day to day and pay back? | Stock plan, staffing needs, budget, BOQ |

## Store formats and what each demands

| Format | Main priority | Typical constraints | Design emphasis |
|---|---|---|---|
| Flagship | Brand statement and experience | Large budget, high expectations | Hero moments, storytelling, services |
| High-street or mall unit | Clear offer, fast conversion | Narrow frontage, landlord rules | Facade, window, entrance, first 3 metres |
| Shop-in-shop / concession | Visibility inside someone else's space | Host-store rules, small footprint | Modular fixtures, signage, brand block |
| Pop-up | Speed and impact | Short lease, low budget, no permanent fixing | Reusable kit, transport, quick install |
| Kiosk / island | Impulse and visibility from all sides | 360° visibility, tiny storage | Compact fixtures, lighting, security |
| Showroom / experience centre | Demonstration and consultation | Display of large products | Zoning, demo areas, seating, samples |
| Café or F&B-led retail | Dwell time and atmosphere | Kitchen services, hygiene, ventilation | Seating layout, counter, service flow |

## The in-store customer journey

| Phase | What the customer is doing | Design levers |
|---|---|---|
| Approach | Notices the store from the street or mall | Facade, signage, window, lighting at night |
| Threshold | Decides whether to enter | Entrance width, door type, open sightlines |
| Orientation | Slows down and reads the space | Decompression zone, hero display, wayfinding |
| Discovery | Browses | Fixture layout, category blocks, colour and light |
| Engagement | Picks up, compares, asks | Display height, touch points, staff positions, product information |
| Trial | Tries, tests, sits | Fitting rooms, demo stations, seating, mirrors, lighting |
| Purchase | Pays | Cash-wrap location, queue space, add-on displays |
| Exit | Leaves, remembers | Last impression, packaging, loyalty prompts |

## Commercial terms designers should know

| Term | Plain meaning | Why a designer cares |
|---|---|---|
| Footfall | People passing or entering | Facade and window have to earn attention |
| Capture (entry) rate | Share of passers-by who enter | Measures the effect of facade and window |
| Conversion rate | Share of visitors who buy | Measures layout, staff, stock and display |
| Average transaction value | Spend per purchase | Cross-merchandising and add-on displays |
| Dwell time | How long visitors stay | Seating, experiences and comfort |
| Sales density | Sales per unit of area | Whether space is working hard enough |

You rarely control these alone, but your design choices should be tied to at least one of them.

## Project stages

| Stage | Key decisions | Main deliverables |
|---|---|---|
| 1. Brief | Objectives, audience, budget, programme | Design brief, questionnaire answers |
| 2. Concept | Big idea, mood, zoning direction | Mood boards, concept statement, sketches |
| 3. Space planning | Layout, flow, adjacencies | Plan options, preferred layout |
| 4. Design development | Materials, fixtures, lighting, signage | 3D views, material board, fixture schedule |
| 5. Documentation | What exactly gets built | Drawings, specifications, BOQ, tender pack |
| 6. Procurement and fit-out | Who builds, when, at what price | Vendor quotes, site coordination, snag lists |
| 7. Handover and VM launch | Opening readiness | Handover checklist, VM guide, opening displays |
| 8. After opening | What works and what to fix | Audit, refresh plan, lessons learned |

## Where AI helps and where it doesn't

| AI helps with | You and qualified professionals own |
|---|---|
| Exploring many concept directions quickly | Which concept is right for this brand and client |
| Drafting briefs, questionnaires, specs and emails | Facts, quantities and commitments in them |
| Generating layout ideas as text or sketches | Dimensioned drawings, circulation, egress, accessibility |
| Realistic visuals from sketches and models | Scale, structure, services, buildability |
| Variations of windows, signage and social content | Brand approval and legal clearance |
| Repetitive admin (minutes, snag lists, trackers) | Decisions and accountability |

**Working rule: AI proposes, you decide, drawings and suppliers confirm.**

Next: [2. Store planning and customer flow](02-store-planning-and-customer-flow.md)
