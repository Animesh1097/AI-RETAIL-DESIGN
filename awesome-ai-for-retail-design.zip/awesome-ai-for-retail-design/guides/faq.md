# FAQ

**Do I need to code to use this repo?**
No. Everything here is text, tools with web interfaces, and templates. ComfyUI is the most technical tool, and it is optional.

**Can AI replace a retail designer?**
No. It speeds up exploration and drafting. It cannot take responsibility for scale, codes, structure, cost, or the relationship with the client.

**Which tool should I start with?**
For text work, any major assistant. For concept images, Midjourney or Firefly. For layout-faithful renders from a model, Veras. For quick sketch renders in the browser, mnml.ai. See the [tool decision guide](../tools/README.md).

**Can I show AI renders to clients?**
Yes, when labelled as AI-assisted and backed by real drawings. See [legal and ethics](13-legal-ethics-and-client-trust.md).

**Can I use AI images commercially?**
It depends on the tool's terms, your plan, and local law. Read the terms, and keep records.

**Are AI floor plan tools usable for retail?**
Mostly they target homes or offices. Use them for ideas, and draw the real plan in CAD. See [Layout and floor plan tools](../tools/layout-and-floorplans.md).

**How do I keep the renders matching my drawings?**
Render from a 3D model or sketch with structure control, and check overlays. See [Sketch to render](08-sketch-to-render-with-comfyui.md) and [Quality-checking](12-quality-checking-ai-visuals.md).

**How do I stay up to date?**
Tools change monthly. Check the "last reviewed" date on each page, read the vendor's own documentation, and send a pull request when something changes.

**Why are some prompts marked "Starter"?**
They are written from design experience but have not been field-tested for every tool. Mark one as **Field-tested** after you've used it in a real project.
