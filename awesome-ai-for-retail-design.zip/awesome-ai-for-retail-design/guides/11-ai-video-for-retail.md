# 11. AI video for retail

Short videos sell store concepts, show projects, and feed social channels. AI video can animate your stills, but it needs planning to look professional.

## What AI video is good for

- Slow camera moves through a render or photo (push-in, pan, orbit)
- Atmosphere shots: light, steam, fabric movement, reflections
- Concept previews for clients
- B-roll between real footage

## What it struggles with

- Accurate product detail and logos
- Hands, faces, crowds, and long action
- Exact repeatability between clips
- Text on screen (add it in the editor instead)

## Tool roles

| Need | Options |
|---|---|
| Image-to-video | [Runway](../tools/profiles/runway.md), [Kling](../tools/profiles/kling.md), Luma, Pika, Midjourney (image-to-video) |
| Edit and assemble | CapCut, Descript, Adobe Premiere |
| Voiceover | ElevenLabs or your own recording |
| Music | Licensed library, or an AI music tool whose licence covers your use |

## A planning template for a 30-second reel

| Part | Time | Purpose | Shot ideas |
|---|---|---|---|
| Hook | 0 to 10 s | Stop the scroll | Striking hero view, quick push-in, bold on-screen line |
| Build | 10 to 20 s | Show the idea or process | Concept to render, details, materials |
| Payoff | 20 to 30 s | Result and action | Finished space, brand line, call to action |

## Clip-generation tips

1. **Start from a strong still.** The first frame defines the look.
2. **One motion per clip:** "slow dolly forward", not "pan, zoom, and orbit".
3. **Keep clips short** (about 5 to 10 seconds) and stitch them in an editor.
4. **Describe stable things:** "static fixtures, no people, no changes to signage".
5. **Generate several takes** and pick the best.
6. **Use start and end frames** where the tool supports them, to control where the shot lands.
7. **Upscale last.**

Prompt shape:

```text
Slow dolly-in towards the feature wall of a warm minimalist boutique. Soft cove lighting, subtle light shimmer on brass trims. Fixtures remain still. No people, no text. 24 mm lens, smooth motion.
```

## Platform basics

| Item | Guidance |
|---|---|
| Format | Vertical 9:16, 1080 × 1920 for Reels and Shorts |
| Safe area | Keep key text and faces away from the top and bottom edges, where app controls overlay |
| Pacing | Change the shot every 2 to 4 seconds |
| Captions | Always add them. Many people watch without sound |
| First seconds | The hook must work in about the first 2 seconds |

## Continuity across clips

Keep the same: presenter or voice, music mood, colour grade, font, and logo treatment. Use stills from the same approved set as start frames.

## Licensing and disclosure

- Read each tool's commercial-use terms for video, music, and voices.
- Never clone someone's voice or likeness without written consent.
- Follow each platform's rules for labelling AI-generated content.
- Some tools run on servers in different regions. Check data and licensing terms for client work.

Prompt: [Reel script](../prompts/content/reel-script.md) · Workflow: [Store reel in a day](../workflows/store-reel-in-a-day.md)

Previous: [10. Documentation](10-ai-for-documentation-boq-and-vendors.md) · Next: [12. Quality-checking AI visuals](12-quality-checking-ai-visuals.md)
