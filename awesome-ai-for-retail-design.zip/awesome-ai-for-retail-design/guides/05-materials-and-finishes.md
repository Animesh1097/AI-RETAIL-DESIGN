# 5. Materials and finishes

Materials create the feel of a store, and also decide cost, durability, and maintenance. This guide gives you a starting library and a process for choosing, so AI shortlists don't turn into specification mistakes.

> Availability, specifications, and prices vary by country and supplier. Treat this as a starting vocabulary. Verify with suppliers, samples, and the code.

## How to choose

Check each candidate against:

| Criterion | Questions |
|---|---|
| Brand fit | Does it express the concept and price positioning? |
| Durability | Will it survive foot traffic, trolleys, cleaning? |
| Safety | Slip resistance, fire rating, emissions |
| Maintenance | Cleaning method, stain risk, repair options |
| Acoustics | Hard surfaces add echo; soft ones absorb it |
| Lead time | Is it available within the project schedule? |
| Cost | Material plus installation, and cost of replacement |
| Sustainability | Recycled content, certification, end of life |
| Consistency | Can you get the same batch and finish later for repairs? |

## Flooring

| Option | Strengths | Watch out for |
|---|---|---|
| Polished concrete / screed | Durable, modern, continuous | Can be cold and noisy, needs good sealing |
| Terrazzo | Durable, distinctive, premium | Cost, joints, labour skill |
| Large-format tiles (ceramic, vitrified, porcelain) | Many looks, durable, easy to clean | Grout lines, slip rating, lippage |
| Natural stone | Premium, unique | Cost, staining, weight, variation |
| Engineered wood | Warm, premium | Moisture, scratches, maintenance |
| Vinyl / LVT | Cost-effective, many looks, comfortable | Perceived value, heavy loads, adhesive |
| Carpet tiles | Acoustic, comfortable, zoning | Wear in high-traffic areas, cleaning |

## Walls

| Option | Strengths | Watch out for |
|---|---|---|
| Paint | Cheap, flexible, quick to refresh | Surface prep decides quality |
| Microcement / plaster finishes | Seamless, tactile | Skilled labour, cracking, sealing |
| Timber veneer / laminate panels | Warm, scalable | Edge detail, moisture, joint lines |
| Fluted or textured panels | Depth and rhythm | Dust, cost, cleaning |
| Fabric panels | Acoustic, soft | Cleaning, fire rating |
| Glass / mirror | Light and space | Fingerprints, safety glass requirements |
| Metal (brass, steel, aluminium sheet) | Premium accents | Fingerprints, reflections, cost |
| Slatwall / pegboard systems | Flexible merchandising | Looks utilitarian unless detailed well |

## Ceilings

| Option | Strengths | Watch out for |
|---|---|---|
| Painted gypsum / plasterboard | Clean, integrates lighting | Service access, joints |
| Exposed services (painted) | Industrial look, cost saving | Dust, tidy services needed |
| Baffles / acoustic panels | Acoustic control, rhythm | Cost, fire and service coordination |
| Stretch ceilings | Smooth, can be lit | Heat from fixtures, access |

## Fixtures and counters

| Option | Strengths | Watch out for |
|---|---|---|
| Powder-coated steel | Strong, slim, many colours | Chipping at edges |
| Laminate / HPL on board | Cost-effective, durable | Edge banding quality |
| Solid surface (e.g. mineral composites) | Seamless counters, repairable | Cost, heat marks |
| Stone / quartz tops | Premium, durable | Weight, cost |
| Glass and acrylic | Lightness, display clarity | Scratches, fingerprints, safety |
| Timber (solid or veneer) | Warm, premium | Movement, finish durability |

## Build a material schedule

For each finish keep: code (F1, W2, C1), area, material, finish, colour, supplier, product code, size, fire rating, slip rating (floors), cost tier, lead time, sample status, approval date. Use the [finish schedule template](../templates/finish-schedule.csv).

## Using AI for materials

| Good uses | Not good uses |
|---|---|
| Brainstorm combinations that fit a concept | Trusting stated fire ratings, slip ratings, or prices |
| Compare pros and cons for each zone | Confirming availability in your country |
| Draft questions to ask suppliers | Replacing physical sample checking |
| Describe materials precisely for prompts | Choosing without checking maintenance |

Prompt: [Materials and finishes shortlist](../prompts/planning/materials-finishes.md)

**Prompt vocabulary:** say "fluted oak veneer panels with 20 mm ribs" instead of "wood", "honed Kota stone floor" or "light grey terrazzo with small marble chips" instead of "stone floor".

Previous: [4. Retail lighting](04-retail-lighting.md) · Next: [6. AI across the project lifecycle](06-ai-across-the-project-lifecycle.md)
