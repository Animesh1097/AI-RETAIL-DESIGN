# Glossary

## AI and image generation

| Term | Plain meaning |
|---|---|
| Prompt | The instruction you give an AI tool |
| Negative prompt | Things you tell some tools to avoid |
| Reference image | An image the AI uses for look, layout, or composition |
| Style reference | A reference used only for the look (colour, light, texture) |
| Image-to-image | Generating a new image from an existing one |
| Image-to-video | Animating a still into a short clip |
| Inpainting | Regenerating only a selected area |
| Outpainting | Extending an image beyond its borders |
| Upscaling | Increasing resolution and detail |
| Seed | A number that makes a result repeatable or variable |
| ControlNet | A technique that makes a model follow the structure of an input (edges, depth) |
| Depth map | A greyscale image showing how far each part of a scene is |
| Canny / line art | Edge extraction methods used to follow outlines |
| LoRA | A small add-on model that teaches a base model a style or subject |
| Checkpoint | A full model file you load in tools like ComfyUI |
| Diffusion model | The type of model behind most current image generators |
| Hallucination | Confident but wrong output from an AI |
| Credits | Usage units some tools charge for generations |

## Retail and design

| Term | Plain meaning |
|---|---|
| VM (visual merchandising) | Presenting product to attract and sell |
| Planogram | A diagram of where products sit on shelves |
| Facings | Number of units of a product visible at the front of a shelf |
| POP / POS | Point-of-purchase / point-of-sale material such as signs and stands |
| FF&E | Furniture, fixtures, and equipment |
| Fit-out | Constructing and finishing the interior of a store |
| BOQ | Bill of quantities: itemised list of work and materials |
| RFQ | Request for quotation sent to vendors |
| Snag list | List of defects or unfinished items at handover |
| Cash wrap | The checkout counter and packing area |
| Decompression zone | Entrance area where customers adjust to the store |
| Gondola | Freestanding shelving unit on the sales floor |
| Elevation | A flat drawing of a wall or facade |
| Section | A drawing cut through a space |
| Axonometric | A 3D-style drawing with parallel lines, no perspective |
| Shopfitter | Contractor who builds store interiors |
| Lux | Unit of light level on a surface |
| CRI | How accurately a light shows colours |
| CCT | Colour temperature of a light, in kelvin |
