# 10. AI for documentation, BOQ and vendors

Much of a retail project is paperwork: briefs, schedules, bills of quantities (BOQ), emails, minutes, snag lists. AI is excellent at the first draft and structure, and poor at facts it cannot see. This guide shows where to use it safely.

## The rule

**AI builds the structure and drafts the words. You supply and check every number.**

## What AI can do well

| Task | How AI helps | What you provide |
|---|---|---|
| BOQ skeleton | Creates sections and line-item headings for a store fit-out | Quantities, units, and rates from your drawings and vendors |
| Finish schedule | Formats finishes into a consistent table | Codes, products, suppliers |
| Specification wording | Drafts clear, consistent descriptions | Actual product data and standards |
| Vendor RFQ emails | Writes clear requests with scope and deadlines | Scope, drawings, contacts |
| Quote comparison | Lays out quotes side by side, highlights gaps | The quotes themselves |
| Meeting minutes | Converts notes to actions with owners and dates | Notes and decisions |
| Snag lists | Organises site observations by area and priority | Photos, notes, inspection results |
| Change log | Summarises changes and their impact | The actual changes |

## What AI should not do

- Invent quantities or rates
- Read a drawing and give measurements you rely on
- Decide fire, structural, or accessibility compliance
- Replace the contractor's or engineer's responsibility

## Typical fit-out BOQ sections

1. Preliminaries and site setup
2. Demolition and civil work
3. Flooring
4. Wall finishes and partitions
5. Ceiling and bulkheads
6. Joinery, fixtures, and counters
7. Glazing, shopfront, and doors
8. Signage and graphics
9. Electrical and lighting
10. HVAC and ventilation
11. Plumbing (where relevant)
12. Fire protection and safety
13. Loose furniture and equipment
14. Testing, commissioning, and handover

Use the [BOQ template](../templates/boq-template.csv) and the [BOQ skeleton prompt](../prompts/documentation/boq-skeleton.md).

## Workflow

1. Share the finished design description and drawings list with the AI (no confidential details).
2. Ask for a BOQ skeleton and a list of items often forgotten.
3. Fill quantities from your drawings and takeoff.
4. Get vendor rates. Add them yourself.
5. Ask AI to check the sheet for missing sections, inconsistent units, and duplicated items.
6. Review manually.

## Vendor communication

- State scope, drawings, deadline, delivery location, warranty, and payment expectations.
- Ask for **itemised** quotes so you can compare.
- Keep a log of questions and answers.

Use the [vendor RFQ prompt](../prompts/documentation/vendor-rfq-email.md).

## Confidentiality

- Remove client names, addresses, and unreleased brand information unless your tool and contract allow it.
- Check whether the tool stores or trains on your inputs. Use business or API plans with data controls when required.

## Reading drawings with AI

Vision-capable assistants can describe a plan or a photo. They make mistakes with scale, small text, and complex drawings. Use them to prompt your own checks ("what clearances should I verify?") and never to produce numbers you rely on.

Previous: [9. Consistency](09-keeping-renders-consistent.md) · Next: [11. AI video for retail](11-ai-video-for-retail.md)
