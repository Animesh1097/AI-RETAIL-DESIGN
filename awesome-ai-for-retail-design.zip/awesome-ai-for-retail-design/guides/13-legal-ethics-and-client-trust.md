# 13. Legal, ethics and client trust

This is practical guidance, not legal advice. Laws and tool terms vary by country and change often. For important projects, talk to a lawyer and read each tool's current terms.

## Ownership and copyright

- In several jurisdictions, including the United States, purely machine-generated output may not be eligible for copyright, while human-authored selection, arrangement, and edits can be. The rules differ elsewhere and are still developing.
- **Practical effect:** you may be unable to stop others from reusing an AI-only image. Add substantial human design work, and rely on contracts rather than copyright alone.
- Your tool's terms decide what you may do with outputs, such as commercial use, resale, and attribution. Read them.

## Training data and indemnification

- Tools differ in how their models were trained, and some are involved in copyright lawsuits. Check current news if this matters to your client.
- Some vendors offer **IP indemnification** for certain products and customer tiers. For example, Adobe offers indemnification for eligible enterprise customers on certain Firefly outputs, and coverage depends on plan, model, and whether a feature is in beta. Partner models and beta features can be excluded. **Read your own contract.**
- If a client needs legal certainty, choose tools with clear commercial terms, or limit AI to internal ideation and create final assets by hand.

## Trade dress and brand imitation

- Do not prompt for another brand's store, logo, or distinctive look.
- Do not use named living artists or designers as style prompts in client work.
- Run a basic originality check on logos and signage.

## Confidentiality and data

- Don't paste confidential plans, contracts, or unreleased products into tools that retain or train on your data, unless your agreement allows it.
- Anonymise client names, addresses, and financial details in prompts.
- Prefer business or API plans with data controls for client work, or run models locally.
- Be careful with tools that process data in other jurisdictions.

## People, likeness and voice

- Do not generate or edit images of real people without permission, including staff and customers.
- Get written consent before using anyone's voice or likeness in AI-generated content.
- Avoid depicting identifiable people in AI renders of stores.

## Disclosure and honesty

- Label AI-generated or AI-assisted visuals in pitches and publications.
- Don't present a render as a photograph of a finished space.
- Where platforms require AI labels, use them.

## Professional responsibility

AI doesn't hold a licence. You remain responsible for safety, compliance, accuracy, and quality. Keep records showing who reviewed and approved what.

## Sample wording for proposals (adapt with legal advice)

> **Use of AI tools.** We may use generative AI tools during concept development and visualisation. Final design intent is defined by approved drawings and specifications, which prevail over any AI-assisted visuals. We do not upload confidential client information to AI tools without your consent. AI-assisted visuals are labelled as such.

## Ethical habits

- Credit sources, prompt authors, and contributors.
- Keep human craftspeople in the loop. AI is a tool for them, not a reason to ignore them.
- Be open with clients about what AI did and what you did.

Previous: [12. Quality-checking](12-quality-checking-ai-visuals.md) · Back to [guide index](../README.md#guides)
