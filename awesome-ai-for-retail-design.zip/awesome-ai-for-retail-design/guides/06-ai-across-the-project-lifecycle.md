# 6. AI across the project lifecycle

A map of where AI fits in a retail project, what to use it for, what to keep human, and which part of this repo to open.

## Lifecycle map

| Stage | AI is useful for | Keep human | Tools | Prompts and workflows |
|---|---|---|---|---|
| Discovery and brief | Structuring notes, listing questions, summarising research | Talking to the client, observing the site | [Assistants](../tools/profiles/assistants.md) | [Questionnaire](../prompts/discovery/client-discovery-questions.md), [Brief to design brief](../prompts/discovery/brief-to-design-brief.md) |
| Research | Summarising competitor observations, finding patterns | Visiting stores, judging real quality | Assistants | [Competitor audit](../prompts/discovery/competitor-store-audit.md) |
| Concept | Mood directions, concept statements, naming | Choosing the idea and telling the story | [Midjourney](../tools/profiles/midjourney.md), [Firefly](../tools/profiles/adobe-firefly.md) | [Mood board](../prompts/concept/concept-moodboard.md), [Concept narrative](../prompts/concept/concept-narrative.md) |
| Space planning | Programme, adjacency, zoning options as text, critique | The plan, dimensions, codes | Assistants, [Layout tools](../tools/layout-and-floorplans.md) | [Zoning and flow](../prompts/planning/zoning-and-flow-options.md) |
| Design development | Material shortlists, lighting concepts, fixture lists | Specification, details, compliance | Assistants | [Materials](../prompts/planning/materials-finishes.md), [Lighting](../prompts/planning/lighting-concept.md), [Fixture schedule](../prompts/planning/fixture-schedule.md) |
| Visualisation | Renders from sketches or models, revisions, upscaling | Fidelity to the drawings | [ComfyUI](../tools/profiles/comfyui.md), [Veras](../tools/profiles/veras.md), [mnml.ai](../tools/profiles/mnml-ai.md) | [Sketch to render](../prompts/visualisation/sketch-to-render.md), [Revisions](../prompts/visualisation/render-revision-inpainting.md) |
| Documentation and BOQ | Structure, checklists, spec drafts, emails | Quantities, rates, drawings | Assistants | [BOQ skeleton](../prompts/documentation/boq-skeleton.md), [Vendor RFQ](../prompts/documentation/vendor-rfq-email.md) |
| Procurement and fit-out | Comparing quotes, minutes, action lists, snag lists | Negotiation, site checks, safety | Assistants | [Minutes to actions](../prompts/documentation/meeting-minutes-to-actions.md), [Snag list](../prompts/documentation/snag-list-and-handover.md) |
| VM and launch | Window concepts, VM calendar, signage copy | Physical installation | [Photoroom/Pebblely/Flair](../tools/visual-merchandising.md) | [Window display](../prompts/merchandising/window-display.md) |
| Content and marketing | Reel scripts, captions, video clips, case studies | Brand voice and approval | [Runway](../tools/profiles/runway.md), [Kling](../tools/profiles/kling.md) | [Reel script](../prompts/content/reel-script.md) |
| After opening | Audit notes into a refresh plan | Measuring results | Assistants | [Store audit workflow](../workflows/store-audit-to-refresh-plan.md) |

## Maturity ladder

| Level | What it looks like | Start with |
|---|---|---|
| 1. Assistant | AI writes drafts of briefs, specs, emails | An assistant and the prompts in `discovery/` and `documentation/` |
| 2. Concept visuals | AI produces mood and concept imagery | Midjourney or Firefly |
| 3. Controlled visuals | Renders follow your sketches or 3D models | Veras, mnml.ai, or ComfyUI |
| 4. Repeatable workflows | Templates, prompt log, checklists used by the whole team | [Templates](../templates/) |
| 5. Automation | Steps chained together (brief → tasks → assets) | n8n or Make, only after level 4 is stable |

Skipping levels usually wastes time. A team without a clean brief gains nothing from automating it.

## Rules for every stage

1. **Define the outcome first.** What decision will this output help you make?
2. **Give context.** AI output is only as specific as your input. Use the [client questionnaire](../templates/client-questionnaire.md).
3. **Keep a prompt log.** Record the tool, prompt, settings, and verdict. Use the [prompt log template](../templates/prompt-log-template.csv).
4. **Verify before you share.** Use the [render QA checklist](12-quality-checking-ai-visuals.md) and the [legal notes](13-legal-ethics-and-client-trust.md).
5. **Label AI work** in client material.

Previous: [5. Materials](05-materials-and-finishes.md) · Next: [7. Prompting for retail visuals](07-prompting-for-retail-visuals.md)
