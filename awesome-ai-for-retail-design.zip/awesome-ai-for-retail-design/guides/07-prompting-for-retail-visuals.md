# 7. Prompting for retail visuals

How to write prompts that give you usable store imagery, and what to do when they don't.

## Prompt anatomy

Write prompts as a short design brief. Cover these elements in roughly this order:

| Element | What to say | Example |
|---|---|---|
| Subject and format | Store type, size, location | "Boutique skincare store, 60 m², mall unit" |
| Concept and style | The idea in a few words | "calm clinical luxury with botanical touches" |
| Materials | Specific, with finish | "pale oak veneer shelving, honed limestone floor, brushed steel trims" |
| Colour palette | 3 to 4 colours | "ivory, sage green, warm grey, brass" |
| Lighting | Type, temperature, mood | "soft warm cove lighting, accent spots on products" |
| Composition and camera | View, lens, height | "wide-angle 24 mm, eye-level, one-point perspective from the entrance" |
| Key features | What must be visible | "central display island, back wall with niches, cash wrap on the right" |
| Atmosphere | Time, mood | "calm weekday morning" |
| Constraints | What to exclude | "no people, no text, no logos, realistic proportions" |

## Views you can ask for

| View | Prompt phrase | Use |
|---|---|---|
| Entrance view | "eye-level view from the entrance, one-point perspective" | First impression |
| Hero view | "view towards the feature wall, 24 mm wide-angle" | Concept hero |
| Corner view | "two-point perspective from the corner" | Showing the whole space |
| Detail | "close-up of the display shelf, shallow depth of field" | Materials, product display |
| Axonometric | "axonometric cutaway of the store layout" | Layout explanation (check accuracy) |
| Facade | "street-level view of the shopfront at dusk" | Exterior and signage |

## Vocabulary bank

**Mood:** calm, intimate, gallery-like, energetic, playful, theatrical, understated, tactile, warm minimal, industrial, artisanal, heritage, futuristic.

**Lighting:** soft cove lighting, warm accent spots, wall-washed feature wall, pendant lights, skylight daylight, dusk glow, high-contrast accent lighting.

**Materials and finishes:** fluted oak, walnut veneer, honed limestone, terrazzo with small chips, polished concrete, brushed brass, blackened steel, bouclé fabric, ribbed glass, microcement, mirror, linen panels.

**Fixtures:** gondola shelving, wall-hung shelves, plinth, display table, rail, wall-mounted niches, floating shelves, glass display case, mannequin platform, cash wrap with stone top.

## Prompt patterns

**1. Spec-sheet style** (best for control)

```text
Interior of a [store type]. Layout: [key features and positions].
Materials: [list]. Palette: [list]. Lighting: [description].
View: [camera]. Realistic photograph, no people, no text.
```

**2. Narrative style** (best for mood)

```text
A calm, high-end [store type] on a quiet street, with [materials] and [lighting]. Customers would feel [feeling]. Wide-angle architectural photograph.
```

**3. Reference style** (best for consistency)

Upload an approved image and say: "Keep the layout and camera of image 1, use the materials and mood of image 2."

## Iteration strategy

1. **Explore wide:** change one variable (style, material, light) per round.
2. **Narrow:** pick one direction and lock the spec (materials, palette, lighting).
3. **Fix:** use inpainting or edit tools for local problems instead of regenerating everything.
4. **Finish:** upscale, then check and clean up in an image editor.

## Common failure modes and fixes

| Problem | Why it happens | Fix |
|---|---|---|
| Floating fixtures or shelves | Model doesn't understand structure | Add "fixtures fixed to wall and floor", use a structure reference or inpaint |
| Warped perspective or bending lines | Wide angle plus busy scene | Request "straight vertical lines, architectural photography", use 24 to 35 mm, simplify |
| Impossible stairs or doors | Weak spatial logic | Remove them from the prompt or crop them out |
| Wrong scale (tiny doors, huge counters) | No scale reference | Add "standard door height 2.1 m", include a counter or chair for scale |
| Garbled text and logos | Text is hard for many models | Prompt "no text", add real signage in an editor |
| Duplicated objects and mannequins | Repetition bias | Describe numbers: "three mannequins", or inpaint |
| Too perfect, empty feel | Over-clean output | Add a few real-life details: "small plant, shopping bag, product tags" |
| Layout drifts from your sketch | Weak structure control | Use depth or edge control (Veras, ComfyUI), lower creativity |

## Example prompts by store type

> Starter prompts to adapt. They are untested for your tool.

**Jewellery boutique**
```text
Interior of a luxury jewellery boutique, 45 m², warm minimalism with Indian craft details. Materials: sandstone floor, brass inlay lines, walnut veneer cabinets, ivory plaster walls. Palette: sand, deep green, brass, ivory. Lighting: warm 2700K cove lighting, narrow accent spots inside glass display cases. Central display island, arched back wall with illuminated niches. Eye-level view from the entrance, 24 mm, realistic photograph, no people, no text.
```

**Fashion store**
```text
Interior of a contemporary menswear store, 120 m², industrial luxe. Polished concrete floor, blackened steel rails, oak shelves, mirror panels. Palette: charcoal, tan, off-white, brass. Track lighting with warm spots on garments. Central table display, wall rails on both sides, fitting rooms at the back. View from the entrance, wide-angle, realistic, no people, no text.
```

**Café with retail corner**
```text
Interior of a specialty coffee café with a small retail wall, 80 m². Terrazzo counter, ribbed oak panels, terracotta tiles, green plants. Palette: cream, terracotta, deep green, oak. Warm pendant lights over the counter, daylight from large windows. Corner view showing the counter, seating, and retail shelf wall. Calm morning, no people, no text.
```

**Consumer electronics store**
```text
Interior of a modern consumer electronics store, 150 m². White matte surfaces, light oak tables, slim black shelving, continuous LED ceiling strips. Palette: white, oak, black, one accent blue. Even bright lighting at 4000K with accent on hero products. Demo tables in the centre, wall display behind, service desk to the right. Eye-level view, realistic, no people, no text.
```

**Pharmacy / wellness**
```text
Interior of a calm modern pharmacy and wellness store, 90 m². Light oak, white solid-surface counter, soft green wall panels, pale vinyl floor. Even lighting at 3500K, clear signage zones. Grid of low shelves, consultation desk on the right, dispensing counter at the back. Eye-level view from the entrance, realistic, no people, no text.
```

**Bookstore**
```text
Interior of an independent bookstore, 100 m². Floor-to-ceiling walnut shelving with rolling ladder, central display tables, reading corner with armchairs, green carpet. Warm 2700K lighting, pendant lamps, soft accent lighting on shelves. View from the entrance towards the reading corner, realistic, no people, no text.
```

Previous: [6. Lifecycle](06-ai-across-the-project-lifecycle.md) · Next: [8. Sketch to render with ComfyUI](08-sketch-to-render-with-comfyui.md)
