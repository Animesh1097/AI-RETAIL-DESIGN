# 4. Retail lighting

Light is the cheapest way to change how a store feels, and the first thing AI renders get wrong. This guide gives you the vocabulary to plan lighting and to describe it in prompts.

> Figures here are **commonly used ranges**. Final lighting design needs a lighting designer or calculations (for example in DIALux or Relux) with real fixture data, and must meet local energy and safety codes.

## Four layers of light

| Layer | Purpose | Typical fixtures |
|---|---|---|
| Ambient (general) | Safe, comfortable base level | Recessed downlights, linear panels, cove light |
| Accent (display) | Draws the eye to products and features | Track spots, adjustable recessed spots, framing projectors |
| Task | Helps staff and customers do things | Cash wrap lights, fitting-room mirror lighting, display-case lighting |
| Decorative | Gives character and brand identity | Pendants, neon, sculptural fixtures |

Strong stores use **contrast**: the hero is brighter than its surroundings, so the eye knows where to go.

## Ranges often used in practice

| Parameter | Common range | Notes |
|---|---|---|
| Ambient illuminance | Roughly 300 to 500 lux for many boutique formats; higher in grocery and big-box | Depends on brand tone and local standards |
| Accent-to-ambient ratio | About 3:1 to 5:1 for normal emphasis; higher (up to 10:1 or more) for dramatic luxury moments | Too much contrast tires the eye |
| Colour temperature (CCT) | 2700 to 3000 K warm; 3000 to 3500 K neutral-warm; 4000 K cooler and brighter | Keep consistent across the store |
| Colour rendering (CRI) | 90+ for fashion, jewellery, food, and cosmetics | Low CRI makes colours look dull or wrong |
| Beam angle | Narrow spot (about 10 to 24°) for hero items; medium (about 25 to 40°) for groups; flood (about 40°+) for walls | Choose by display height and distance |
| Aiming angle | Around 30° from vertical for accent lighting | Reduces glare and shadows on the product |

## Lighting by area

| Area | Goal | Tips |
|---|---|---|
| Facade and window | Attract attention day and night | Plan separate scenes for day and night. Avoid glare on glass. |
| Entrance | Welcoming, clear | Slightly brighter than the street at dusk. |
| Feature wall | Visual anchor | Use wall washers for even light or spots for texture. |
| Shelves and fixtures | Product visibility | Integrate light into shelves where possible. |
| Fitting rooms | Flattering and accurate | Light from both sides of the mirror, avoid harsh downlights. |
| Cash wrap | Efficient and welcoming | Provide task light without glare on screens. |
| Display cases | Sparkle and detail | Use quality, glare-free case lighting and good CRI. |

## Common mistakes

- Lighting only the floor and leaving walls and products dark
- Mixing colour temperatures by accident
- Glare and reflections on glass, polished stone, or screens
- Lighting that looks good in daylight but flat at night
- No controls: no dimming, no scenes for opening, daytime, and evening

## AI and lighting

**Good uses**
- Draft a **lighting concept** with layers, areas, and moods ([prompt](../prompts/planning/lighting-concept.md)).
- Describe lighting in render prompts to explore mood.
- Compare lighting scenes (daytime, evening) in visuals.

**Do not**
- Treat the light levels in a render as real. AI invents lighting that looks good but isn't physically calculated.
- Skip calculations and a lighting designer for projects that need compliance.

**Words that work in image prompts**

| You want | Try |
|---|---|
| Warm, calm | "warm 2700K lighting, soft cove light, gentle shadows" |
| Dramatic display | "narrow-beam accent spotlights on the hero display, darker surroundings" |
| Fresh, bright | "bright neutral 4000K lighting, even illumination, soft shadows" |
| Evening mood | "dusk exterior, warm interior glow through large windows" |
| Gallery feel | "wall washers on the back wall, spotlights on plinths" |

Previous: [3. VM principles](03-visual-merchandising-principles.md) · Next: [5. Materials and finishes](05-materials-and-finishes.md)
