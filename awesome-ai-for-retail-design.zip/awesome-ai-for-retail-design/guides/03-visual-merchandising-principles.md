# 3. Visual merchandising principles

Visual merchandising (VM) is the craft of presenting product so people notice it, understand it, and want it. These principles apply whether you are dressing a window, a wall, or one shelf.

## Hierarchy: hero, support, fill

| Level | Job | Example |
|---|---|---|
| Hero | Stops the eye | One feature product or a bold installation |
| Support | Explains the hero and builds the story | Related products, props, graphics |
| Fill | Supplies the range | Regular stock on shelves and rails |

Every display needs a clear hero. If everything shouts, nothing is seen.

## Composition rules that work

- **Odd numbers.** Groups of three or five look natural. Even groups feel static.
- **Triangle or pyramid.** Arrange items so the eye moves up to a peak and down again.
- **Repetition and rhythm.** Repeat a shape, colour, or spacing, then break it once for interest.
- **Negative space.** Leave breathing room. Crowding reduces perceived value.
- **Colour blocking.** Group by colour, tone, or gradient so shelves read as a clean field.
- **Scale and height variation.** Mix heights with risers and stands so items don't line up like a wall.

## Eye-level zones (rules of thumb)

| Zone | Approx. height | Use |
|---|---|---|
| Stretch | Above about 1.7 m | Signage, brand moments, lightweight items |
| Eye / hot zone | About 1.2 to 1.7 m | Best sellers, new arrivals, high margin |
| Hand | About 0.8 to 1.2 m | Items to touch and pick up |
| Stoop | Below about 0.8 m | Bulk, heavy, or replenishment stock |

## Windows

| Window type | Description | Best for |
|---|---|---|
| Open back | Interior is visible through the window | Inviting stores, showing life inside |
| Closed back | Solid back panel | Controlled theatre, luxury, small displays |
| Semi-closed | Partial back with openings | Balance of staging and glimpses of the store |
| Shadow box | Small enclosed display | Jewellery, cosmetics, accessories |

Window checklist:
- Designed for a **glance**: one idea, readable from across the street
- Lit for **daytime and night**, with no glare or reflections on the glass
- Hero product and price or offer are clear
- Props and graphics are clean, dust-free, and stable
- The window connects to the **interior** (same colour, story, or product)
- Refreshed on a regular cycle that fits your format and season

## Floor and wall displays

- **Power wall:** the back or feature wall that carries your strongest message.
- **Vertical blocking:** group by category or brand in columns so customers scan down.
- **Cross-merchandising:** place related items together (shirt, belt, bag).
- **Pause points:** install displays at turns or entrances to slow people down.
- **Replenishment:** design displays so staff can refill them quickly.

## Planogram basics

| Term | Meaning |
|---|---|
| Facing | One unit of a product visible at the front of a shelf |
| Share of shelf | Space given to a product or brand relative to the category |
| Vertical vs horizontal blocking | Grouping a category in a column vs along a shelf row |
| Anchor product | The recognisable product that helps customers find the block |

AI can draft rules and logic for a planogram, but final facings and dimensions must come from product sizes and a planogram tool or spreadsheet.

## Signage hierarchy

1. **Brand and category signs:** orient customers from a distance
2. **Feature and offer signs:** promote the hero
3. **Product and price signs:** close the sale

Keep copy short, type legible, and design consistent.

## Seasonal planning

Plan windows and key displays against a **VM calendar** that combines your retail calendar (launches, festivals, sales) with regional and cultural events. Create concepts early, source props with lead time, and photograph every installation for reference.

## Using AI in VM

| Task | How AI helps | Keep in mind |
|---|---|---|
| Window concepts | Generate options, prop lists, and visuals | Check physical feasibility: depth, hanging points, glare |
| Display mockups | Place products into scenes | Keep the real product unaltered and accurate |
| VM calendar | Draft a 12-month plan | Adjust for your market and festivals |
| VM guidelines | Turn a brand book into do and don't rules | Review with the brand team |
| Signage copy | Generate headline options | Proofread. Keep tone on brand |

Prompts: [Window display](../prompts/merchandising/window-display.md) · [VM calendar](../prompts/merchandising/seasonal-vm-calendar.md) · [Planogram brief](../prompts/merchandising/planogram-brief.md)

Previous: [2. Store planning](02-store-planning-and-customer-flow.md) · Next: [4. Retail lighting](04-retail-lighting.md)
