# 12. Quality-checking AI visuals

Every AI visual needs a check before it reaches a client. Many errors are subtle: a door that's too small, a fixture that can't be built, or a logo that has changed.

## Quick scan (60 seconds)

- Does it match the **brief and brand**?
- Does it match the **layout and drawings**?
- Anything **impossible, floating, or duplicated**?
- Any **text or logo** that's wrong?
- Would a client think this is **buildable**?

## Full checklist

| Area | Check | Pass |
|---|---|---|
| Layout | Positions of entrance, counters, fixtures match the plan | ☐ |
| Scale | Doors look about 2.0 to 2.1 m high, counters about 0.9 to 1.1 m, shelves reachable | ☐ |
| Structure | Columns, beams, and walls look supportable and consistent | ☐ |
| Fixtures | Every fixture can be fabricated, fixed, and serviced | ☐ |
| Materials | Match the schedule: floor, walls, ceiling, fixtures | ☐ |
| Lighting | Direction and shadows make sense; no impossible light sources | ☐ |
| Reflections | Mirrors and glass reflect the right things | ☐ |
| Products | Look right and not misleading; no wrong packaging | ☐ |
| Text and logos | Spelled right, correct, not copied from another brand | ☐ |
| People and props | None unintended; any shown are consistent | ☐ |
| Accessibility | Clear routes, counter heights, no steps where none planned | ☐ |
| Safety | Exits visible and not blocked; no unsafe details | ☐ |
| Style match | Mood consistent with the rest of the set | ☐ |
| Artefacts | No smears, extra limbs, merged objects, strange textures | ☐ |
| Labelling | AI-assisted note included in presentation | ☐ |

## Scale check

1. Place a known item in the image (a door, a counter, a person at 1.7 m) and compare.
2. Overlay the render on a screenshot of your 3D model or a plan perspective.
3. Look for items that are suspiciously large or small.

## Red flags

| Red flag | Meaning | Action |
|---|---|---|
| Shelves with no visible support | Not buildable | Redraw or inpaint with supports |
| Rooms that don't match the plan | Layout drift | Re-render with stronger structure control |
| Perfectly symmetrical clutter | AI pattern | Vary items by hand |
| Unreadable or odd signs | AI text problem | Replace in an editor |
| Doors with no frames or handles | Detail error | Fix details |
| Light with no source | Invented lighting | Add fixtures or soften |

## Scoring rubric (optional)

Rate each from 0 to 2 (0 = fail, 1 = needs fixing, 2 = good). Aim for 2 in layout, scale, brand, and labelling before sharing externally.

| Criterion | Score |
|---|---|
| Layout fidelity | |
| Scale and proportion | |
| Buildability | |
| Brand and mood | |
| Text and logos | |
| Consistency with other views | |
| Technical artefacts | |
| Labelling and rights | |

## Sign-off rules

- A designer who understands the drawings signs off every visual used externally.
- Anything used for **approvals or contracts** is backed by drawings, not by the render alone.
- Keep the final prompt, settings, and tool version in the [prompt log](../templates/prompt-log-template.csv).

Template: [Render QA checklist](../templates/render-qa-checklist.md)

Previous: [11. AI video](11-ai-video-for-retail.md) · Next: [13. Legal, ethics and client trust](13-legal-ethics-and-client-trust.md)
