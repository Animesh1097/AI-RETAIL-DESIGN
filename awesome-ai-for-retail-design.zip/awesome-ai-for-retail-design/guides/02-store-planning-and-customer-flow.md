# 2. Store planning and customer flow

How a store is organised decides what customers see, where they go, and what they buy. This guide covers zoning, flow patterns, sightlines, planning checks, and how to use AI without losing control of the plan.

> Numbers in this guide are **common rules of thumb**, not standards. Always check local building, fire, and accessibility codes (for example ADA in the US, the National Building Code in India, Approved Document M in the UK) and validate with the client's operations team.

## Store zones

| Zone | Purpose | Planning notes |
|---|---|---|
| Threshold / decompression | Customer adjusts to the space | Keep it open. Avoid sale bins and heavy fixtures right at the door. |
| Hero / feature zone | States the brand and the offer | Visible from the entrance, often on the first sightline or the back wall. |
| Core merchandise | The main range | Organise by category, brand, use, or customer story. |
| Secondary / destination | Draws people deeper | Place high-demand categories further in to pull traffic through. |
| Service and experience | Fitting, consultation, demo, seating | Needs privacy, comfort, staff access. |
| Cash wrap / checkout | Payment, packing, add-ons | Visible, supervised, with queue space and nearby impulse items. |
| Back of house | Stock, staff, services | Plan stock volumes and replenishment routes early with operations. |

## Flow patterns

| Pattern | How it works | Suits | Watch out for |
|---|---|---|---|
| Grid | Parallel rows of fixtures with straight aisles | Grocery, hardware, pharmacy, books | Can feel utilitarian |
| Loop (racetrack) | A main path loops around the store, with branches | Fashion, department-style stores | Needs clear shortcuts to avoid dead ends |
| Free-flow | Organic arrangement of fixtures | Boutiques, flagships, lifestyle | Harder to navigate, needs strong wayfinding |
| Spine | One central aisle with branches | Narrow, deep stores | The back can feel remote |
| Angled / diagonal | Fixtures rotated to open diagonal sightlines | Small shops with a corner cash wrap | Wastes some floor area |

Observe real behaviour in the target market. Habits such as which way people turn on entering vary by region and format.

## Sightlines and focal points

1. **From the street:** can a passer-by tell what you sell in a glance?
2. **From the door:** is there a clear hero display, and can the eye travel to the back wall?
3. **From the cash wrap:** can staff see the door, fitting rooms entrance, and high-value areas?
4. **Fixture heights:** keep fixtures low near the entrance and towards the centre, and place taller units on the perimeter, so views stay open.

## Common planning targets (verify before use)

| Item | Typical target |
|---|---|
| Accessible route, clear width | At least 915 mm (36 in) in the US under ADA, wider where possible. Check local code. |
| Secondary aisles | About 1.0 to 1.2 m |
| Primary aisles | About 1.5 to 1.8 m, wider in premium formats |
| Wheelchair turning space | About 1.5 m (60 in) diameter in the US under ADA |
| Counter heights | Service counters around 0.9 to 1.1 m, with an accessible lowered section where required |
| Hot zone for display | Roughly waist to just above eye level (about 0.8 to 1.7 m) |

## Planning checks

- [ ] Entrance is clear and the first 2 to 3 metres inside are uncluttered
- [ ] A hero display is visible from the entrance
- [ ] Main route reaches every category without dead ends
- [ ] Queue space at the cash wrap does not block aisles
- [ ] Fitting rooms or demo areas have privacy and staff visibility
- [ ] Stock can be replenished without crossing the shop floor at peak times
- [ ] Emergency exits, fire equipment, and signage are unobstructed
- [ ] Power, data, and lighting positions match the layout
- [ ] Layout can flex for seasonal change

## Score your layout options

Score each option 1 (weak) to 5 (strong), multiply by the weight, and compare. Adjust the weights to the brief.

| Criterion | Weight |
|---|---|
| Visibility from entrance and street | 20 |
| Flow and circulation | 20 |
| Product adjacency and story | 15 |
| Staff efficiency and security | 15 |
| Flexibility for future change | 10 |
| Cost and complexity of build | 10 |
| Brand experience and "wow" | 10 |

## Using AI for planning

**What works**
- Turn a brief into a **space programme** (list of zones with target areas and adjacencies).
- Generate **3 to 5 zoning descriptions** as text, then draw the best ones yourself.
- **Critique a plan** that you describe in text: ask what could go wrong for customers, staff, and security.
- Tools that generate floor plans are mostly built for homes or offices. For retail, treat them as idea generators ([Layout and floor plan tools](../tools/layout-and-floorplans.md)).

**What doesn't**
- AI-generated plans can ignore columns, services, fire exits, and real dimensions.
- Vision models reading a plan image can misjudge scale and miss walls. Do not trust AI-calculated areas.

**Describe a plan in text so AI can critique it**

```text
Store: [type], [area] m², frontage [width] m, depth [depth] m.
Entrance: [position]. Fixed elements: [columns, services, stairs].
Zones and approximate positions: [list].
Fixtures: [types and counts].
Cash wrap: [position]. Fitting rooms: [position]. Stockroom: [position].
```

Then use the [zoning and flow prompt](../prompts/planning/zoning-and-flow-options.md).

Previous: [1. Fundamentals](01-retail-design-fundamentals.md) · Next: [3. Visual merchandising principles](03-visual-merchandising-principles.md)
