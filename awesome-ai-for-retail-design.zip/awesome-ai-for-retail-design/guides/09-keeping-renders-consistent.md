# 9. Keeping renders consistent

A single good image is easy. A set of images that clearly show the same store is harder. Clients notice when the floor changes colour between views.

## Why images drift

AI image tools generate each image fresh. Unless you give them strong structure or reference, materials, proportions, and lighting change from view to view.

## Strategies, from strongest to weakest

| Strategy | How | Best for |
|---|---|---|
| 1. Render from one 3D model | Model once in SketchUp, Rhino, or Revit, and use Veras, mnml.ai, or ComfyUI to restyle each view | Final presentation sets |
| 2. Fixed spec block | Paste the same materials, palette, and lighting text into every prompt | Concept sets |
| 3. Style reference | Use the same approved image as a style reference | Same mood across a series |
| 4. Reference chain | Use approved images as input for the next view | Extending one space |
| 5. Edit rather than regenerate | Use inpainting or edit tools for changes | Revisions after approval |

## Write a spec block

Create one block and reuse it word for word:

```text
STORE SPEC (do not change):
Materials: honed limestone floor, pale oak veneer shelving, ivory plaster walls, brushed brass trims.
Palette: ivory, sage green, warm grey, brass.
Lighting: soft warm cove lighting at 3000K, accent spots on products.
Fixtures: central display island with rounded corners, wall niches with LED edge lighting.
Style: calm, tactile, premium.
```

Then add one line per view:

```text
VIEW: eye-level from the entrance, towards the feature wall, 24 mm.
```

## A series plan

Plan the set before generating:

| View | Purpose | Notes |
|---|---|---|
| 1. Facade at dusk | Street presence | Shows signage and window |
| 2. Entrance view | First impression | Hero feature visible |
| 3. Hero view | Brand moment | Feature wall or display |
| 4. Detail | Materials and product display | Close-up |
| 5. Cash wrap or service | Operations | Staff and customer interface |
| 6. Fitting or experience area | Services | If relevant |

## Consistency checklist

- [ ] Same floor material and colour in all views
- [ ] Same ceiling and lighting style
- [ ] Fixtures have the same shape and finish
- [ ] Signage and logo are identical (add them in an editor)
- [ ] Time of day and colour grade match
- [ ] Proportions agree with the drawings
- [ ] Any people, mannequins, or props are consistent or absent

## Colour consistency

Models seldom match exact colour codes. To control colour:
1. Describe colours in plain words and materials ("sage green lacquer").
2. Generate, then **colour-correct in an image editor** so the set shares a grade.
3. Check final colours against physical samples, never against a screen alone.

## Video continuity

For reels, keep the same presenter, voice, music mood, colour grade, and font across all clips. Start every clip from a still taken from the same approved set. See [AI video for retail](11-ai-video-for-retail.md).

Previous: [8. ComfyUI](08-sketch-to-render-with-comfyui.md) · Next: [10. Documentation, BOQ and vendors](10-ai-for-documentation-boq-and-vendors.md)
