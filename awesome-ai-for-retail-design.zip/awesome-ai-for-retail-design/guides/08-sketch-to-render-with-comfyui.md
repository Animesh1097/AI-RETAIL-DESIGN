# 8. Sketch to render with ComfyUI

ComfyUI gives you the most control over how closely an AI render follows your sketch or 3D screenshot. It takes longer to learn than web tools, so use it when you need repeatable, layout-faithful renders. For a plug-in alternative see [Veras](../tools/profiles/veras.md); for a simpler web tool see [mnml.ai](../tools/profiles/mnml-ai.md).

> Model names, node names, and settings change quickly. Follow the current [ComfyUI documentation](https://docs.comfy.org) and the model's own page. Numbers below are **starting points**, not rules.

## What you are building

```
Your sketch or 3D screenshot
        ↓
Preprocessor (turns it into a depth map or an edge map)
        ↓
Base model + matching ControlNet (keeps the structure)
        ↓
Your prompt (materials, light, mood)
        ↓
Render
```

## Setup choices

| Choice | Options | Advice |
|---|---|---|
| Where to run | Your own computer with a capable GPU, or a cloud service | Local gives privacy and no per-image cost. Cloud avoids hardware setup. |
| Model family | SDXL (lighter, faster), Flux (heavier, sharper) | Start with SDXL if your GPU is modest. |
| Control type | Depth (best for rooms and 3D screenshots), Canny or line art (best for line sketches) | For interiors, depth usually keeps space and scale better. |

**Pairing rule:** a ControlNet must match the base model family. SDXL ControlNets work with SDXL models, and Flux control models work with Flux models. A mismatch is the most common cause of "control doesn't work".

## Prepare your input

- **3D screenshot:** clean white background, simple materials or flat colours, one clear camera view, no UI overlays.
- **Hand sketch:** dark lines on white paper, good light, no shadows, crop to the aspect ratio you need.
- Keep a **consistent aspect ratio** (for example 3:2 or 16:9) across a project.

## Basic workflow (SDXL or Flux)

1. **Load Image** with your sketch or screenshot.
2. **Preprocess:** a depth preprocessor (such as Depth Anything via the `comfyui_controlnet_aux` custom nodes) for 3D screenshots, or Canny / line art for sketches.
3. **Load the base model** (checkpoint) and the **matching ControlNet or control model**.
4. **Write the prompt** with materials, lighting, and mood (see [prompting guide](07-prompting-for-retail-visuals.md)).
5. **Apply the control** to your conditioning and set its strength.
6. **Sample** (KSampler or the equivalent), then **decode** and **save**.
7. **Review** against your source; adjust strength or prompt; render again.

## Starting settings

| Setting | Starting range | Effect |
|---|---|---|
| Control strength | 0.6 to 0.9 | Higher keeps layout tighter, lower gives more creativity |
| Steps | About 25 to 35 for SDXL; about 20 to 30 for Flux dev | More steps adds detail until diminishing returns |
| Guidance (CFG) | About 5 to 7 for SDXL; about 2.5 to 4 for Flux dev | Higher follows the prompt harder but can look harsh |
| Denoise (when starting from your image) | About 0.6 to 0.8 | Lower stays closer to the source |
| Resolution | Native size of the model (e.g. around 1024 px on the long side), then upscale | Rendering huge sizes directly often breaks composition |

## Improve the result

- **Fix local problems with inpainting:** mask the area (a sign, a fixture) and re-render only that.
- **Upscale after approval:** run a dedicated upscale step instead of rendering at huge sizes.
- **Add a style reference:** use an image-prompt or style-reference node to match an approved mood.
- **Save the workflow:** ComfyUI stores the graph and settings in the image or a JSON file, so you can repeat it on the next view.

## Troubleshooting

| Symptom | Likely cause | Try |
|---|---|---|
| Output ignores your layout | Control too weak, wrong model pairing | Raise strength, check model and ControlNet match |
| Output looks flat or overbaked | Guidance too high | Lower CFG or guidance |
| Walls bend, lines wobble | Low-quality depth map or wide-angle chaos | Use a cleaner source, depth instead of edges |
| New objects appear in empty areas | Prompt describes things you didn't draw | Remove those words, add "no extra furniture" |
| Colours don't match the brand | Models don't follow hex codes reliably | Describe the colour in words, correct in an image editor |
| Out of memory | GPU too small | Lower resolution, use SDXL, use a lighter model variant, or run in the cloud |

## Licences matter

Some popular models and community checkpoints have **non-commercial licences** or restrictions. For client work, check the licence of every model, LoRA, and checkpoint you use, and keep a note in your [prompt log](../templates/prompt-log-template.csv).

## Practice exercise

1. Take a clean screenshot of a simple store model (one room, one camera).
2. Create a depth-based render with a warm minimal prompt.
3. Change **only** the materials line, keep everything else. Save three versions.
4. Overlay each result on the source in an image editor and note anything that moved.

Previous: [7. Prompting](07-prompting-for-retail-visuals.md) · Next: [9. Keeping renders consistent](09-keeping-renders-consistent.md)
