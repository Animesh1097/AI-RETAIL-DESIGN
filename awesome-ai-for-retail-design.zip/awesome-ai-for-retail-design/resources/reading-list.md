# Reading list and references

## Books

| Title | Author | Why read it |
|---|---|---|
| *Why We Buy: The Science of Shopping* | Paco Underhill | Observational insight on how people move and shop in stores |
| *Visual Merchandising: Window and In-Store Displays for Retail* | Tony Morgan | Practical VM principles with examples |
| *Visual Merchandising and Display* | Martin M. Pegler | A long-standing reference on displays and windows |
| *Designing Brand Identity* | Alina Wheeler | Brand process that feeds store concepts |
| *Lighting Design Basics* | Mark Karlen and co-authors | Clear introduction to lighting layers and calculations |

## Codes and standards (check the current edition for your location)

- ADA Standards for Accessible Design (United States)
- Approved Document M, access to and use of buildings (United Kingdom)
- National Building Code of India (Bureau of Indian Standards)
- Local fire safety, signage, and municipal rules, and the landlord's tenant design criteria

## Official documentation

- ComfyUI: [docs.comfy.org](https://docs.comfy.org)
- Midjourney: the documentation on the Midjourney website
- Adobe Firefly: Adobe's help pages
- Runway: [help.runwayml.com](https://help.runwayml.com)
- Each tool's terms of service and commercial-use policy

## Lighting calculation software

- DIALux and Relux are commonly used for lighting design calculations with manufacturer fixture data.

## Communities

Online communities around ComfyUI, Midjourney, and AI rendering share workflows and troubleshooting. Treat advice there as ideas to test, and check licences of any shared models.

## How to keep up

1. Re-read the vendor's release notes monthly for the tools you use.
2. Keep a prompt log, and record the tool version used.
3. Re-test your best prompts after major model updates.
4. Send a pull request when something in this repo goes out of date.
