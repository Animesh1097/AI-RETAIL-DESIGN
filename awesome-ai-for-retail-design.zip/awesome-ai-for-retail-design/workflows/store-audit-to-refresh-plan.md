# Store audit to refresh plan

**Time:** half a day · **Output:** a prioritised plan to refresh an existing store

## Steps

| # | Step | Detail |
|---|---|---|
| 1 | Visit and score | Use the [VM audit checklist](../templates/vm-audit-checklist.md) at opening, at peak, and at close. |
| 2 | Observe behaviour | Note where people pause, turn back, or ask for help. |
| 3 | Photograph | Facade, window, entrance, hero displays, cash wrap, problem areas. |
| 4 | Structure the notes | Paste notes into an assistant and ask for problems grouped by impact and effort. |
| 5 | Prioritise | Quick wins (this week), medium (this month), larger works (next quarter). |
| 6 | Visualise options | Edit photos of the store with [inpainting](../prompts/visualisation/render-revision-inpainting.md) or sketch changes. |
| 7 | Plan and cost | Link to the [BOQ workflow](brief-to-boq.md) for larger works. |
| 8 | Re-audit | After changes, repeat the audit and compare. |

## Prompt for step 4

```text
Below are my audit notes for a [store type]. Group the problems by area. For each, give impact on customers or sales (high / medium / low, with reasoning from my notes only), effort (low / medium / high), and a suggested fix. Then propose a 3-tier plan: this week, this month, next quarter.

NOTES:
[paste notes]
```
