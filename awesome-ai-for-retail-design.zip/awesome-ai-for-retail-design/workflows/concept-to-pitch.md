# Concept to pitch

**Time:** about 1 to 2 days · **Output:** a 10 to 12 page pitch with one lead concept and one alternative
**You need:** client notes, an assistant, an image tool, a 3D or sketch tool, Canva, Figma, or PowerPoint

## Steps

| # | Step | How | Output | Check |
|---|---|---|---|---|
| 1 | Clean the brief | [Brief to design brief](../prompts/discovery/brief-to-design-brief.md); send the open questions to the client | One-page brief | Client confirms it |
| 2 | Understand the customer | [Customer journey map](../prompts/discovery/customer-journey-map.md); add your own observations | Journey map | Assumptions marked |
| 3 | Study competitors | Visit stores, then use the [audit prompt](../prompts/discovery/competitor-store-audit.md) | Comparison and gaps | Notes are from real visits |
| 4 | Explore directions | [Mood board prompt](../prompts/concept/concept-moodboard.md), four style lines | 4 directions | Images labelled AI |
| 5 | Choose two | Review against the brief and brand | Two shortlisted directions | Written reasons |
| 6 | Write the narrative | [Concept narrative](../prompts/concept/concept-narrative.md) | Statement, pillars, zone names | Each pillar has a design move |
| 7 | Test the layout | [Zoning options](../prompts/planning/zoning-and-flow-options.md), then draw 3 options and score them | Preferred layout | Scored with the [matrix](../guides/02-store-planning-and-customer-flow.md#score-your-layout-options) |
| 8 | Visualise key views | [Sketch to render](sketch-to-render.md) for entrance, hero, cash wrap | 3 views | [QA](../templates/render-qa-checklist.md) passed |
| 9 | Shortlist materials | [Materials prompt](../prompts/planning/materials-finishes.md); get samples | Material board | Verified with suppliers |
| 10 | Build the pitch | [Pitch outline](../templates/pitch-deck-outline.md) | Deck | Proofread, labelled |

## Pitfalls
- Showing five concepts. Clients choose better from two strong ones.
- Letting a pretty render hide an unworkable layout.
- Promising what the images show without checking the budget.

## Deliverables checklist
- [ ] Brief summary and objectives
- [ ] Concept statement and pillars
- [ ] Layout with flow diagram
- [ ] Three key views, labelled as AI-assisted
- [ ] Materials and lighting direction
- [ ] Indicative timeline and next steps
