# Window display sprint

**Time:** 2 to 3 hours of planning, then install · **Output:** an approved window concept, prop list, and install plan

## Steps

| # | Step | Detail |
|---|---|---|
| 1 | Measure | Window size, depth, hanging points, glare, existing lighting. Take photos. |
| 2 | Concepts | [Window display prompt](../prompts/merchandising/window-display.md), step 1. Ask for five. |
| 3 | Pick one | Score on: clarity at a glance, feasibility, budget, reuse. |
| 4 | Visualise | Step 2 of the prompt, or place a sketch into a photo of your window. |
| 5 | Feasibility | Step 3 of the prompt: risks and install plan. |
| 6 | Source | Prop list with lead times, from the [VM calendar](../prompts/merchandising/seasonal-vm-calendar.md). |
| 7 | Install | Follow the plan. Photograph day and night. |
| 8 | Review | Use the [VM audit checklist](../templates/vm-audit-checklist.md). |
