# Store reel in a day

**Time:** 4 to 6 hours · **Output:** a 30-second vertical reel (1080 × 1920)
**You need:** 3 to 5 approved stills, an assistant, an image-to-video tool, a voice tool or your own recording, an editor ([tools](../tools/video-and-social.md))

## Steps

| # | Step | Detail |
|---|---|---|
| 1 | Pick the story | One message: e.g. "from brief to opening day". |
| 2 | Script | [Reel script prompt](../prompts/content/reel-script.md): three 10-second parts. |
| 3 | Choose start frames | Stills from one approved set so the look is consistent. |
| 4 | Generate clips | 5 to 10 seconds each, one camera move per clip, several takes. |
| 5 | Voiceover | Record or generate. Same voice for all parts. Consent for any voice clone. |
| 6 | Music | Choose a licensed track or a tool whose licence covers your use. |
| 7 | Edit | Cut every 2 to 4 seconds, add captions, keep key text in the safe area. |
| 8 | Review | Watch muted, then with sound. Check spelling and product accuracy. |
| 9 | Publish | Caption, hashtags, AI label where the platform requires it. |

## Pitfalls
- Overlong narration.
- Mixed visual styles across clips.
- Using music or voices without checking the licence.
