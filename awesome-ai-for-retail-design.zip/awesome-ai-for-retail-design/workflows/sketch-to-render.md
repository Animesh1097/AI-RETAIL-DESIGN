# Sketch to render

**Time:** 1 to 2 hours per view · **Output:** a realistic view that matches your layout
**You need:** a clean sketch or 3D screenshot, a render tool ([options](../tools/3d-and-renders.md))

## Steps

| # | Step | Detail |
|---|---|---|
| 1 | Prepare the base | Export one camera view. Simple geometry, flat or simple materials, white background, no interface overlays. Hand sketches: dark lines, even light. |
| 2 | Write the spec block | Materials, palette, lighting, mood. Reuse it for every view ([guide](../guides/09-keeping-renders-consistent.md)). |
| 3 | Choose the tool | Veras for a 3D model in CAD, mnml.ai for screenshots and sketches, ComfyUI for maximum control. |
| 4 | Lock the structure | Highest structure or geometry setting that still gives pleasing results ([ComfyUI guide](../guides/08-sketch-to-render-with-comfyui.md)). |
| 5 | Generate 4 variations | Same prompt, different seeds. Note the settings of the best. |
| 6 | Pick and compare | Overlay the winner on the source. Note anything that moved. |
| 7 | Fix local problems | Use [inpainting prompts](../prompts/visualisation/render-revision-inpainting.md) for signs, fixtures, and artefacts. |
| 8 | Upscale | Only after approval. |
| 9 | Colour-correct | Match the set in an editor. |
| 10 | QA and label | Run the [QA checklist](../templates/render-qa-checklist.md). Add "AI-assisted visual" to the slide. |
| 11 | Log it | Add tool, settings, prompt, and verdict to the [prompt log](../templates/prompt-log-template.csv). |

## Pitfalls
- Starting from a messy screenshot.
- Regenerating the whole image to change one item.
- Trusting scale in the output.
