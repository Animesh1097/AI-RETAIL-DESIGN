# Brief to BOQ

**Time:** 1 to 2 days · **Output:** a structured BOQ with quantities and vendor rates filled in by you
**Rule:** AI creates the structure. You supply and check every number.

## Steps

| # | Step | Detail |
|---|---|---|
| 1 | Freeze the design intent | Concept, plan, material schedule, fixture list, lighting concept. |
| 2 | Draft the skeleton | [BOQ skeleton prompt](../prompts/documentation/boq-skeleton.md) with the design summary. |
| 3 | Add missed items | Ask for "items often forgotten in this project type". |
| 4 | Take off quantities | From your drawings, not from AI. |
| 5 | Request quotes | [Vendor RFQ email](../prompts/documentation/vendor-rfq-email.md) using the BOQ sections. |
| 6 | Enter rates | Compare quotes in a table. |
| 7 | Review | Ask AI to check for missing items, duplicates, and unit mismatches. Review manually. |
| 8 | Issue | Version, date, and revision log. |

Templates: [BOQ](../templates/boq-template.csv) · [Finish schedule](../templates/finish-schedule.csv)
