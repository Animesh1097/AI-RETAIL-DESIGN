# Vendor RFQ email

| | |
|---|---|
| **Goal** | Write a clear request for quotation to a vendor or contractor |
| **Stage** | Documentation |
| **Works with** | Any assistant |
| **Status** | Starter |

## You need
Scope, drawings list, deadline, site details.

## Prompt

```text
Write a request for quotation email to a [joinery / lighting / signage / flooring] vendor.
Project: [type, city]. Scope: [short list]. Attached: [drawings and schedules]. Site access: [details]. Delivery and installation: [dates]. Required in the quote: itemised price, lead time, material and finish specification, warranty, payment terms, and validity period. Quote deadline: [date]. Questions go to: [contact].
Tone: professional, brief. Include a numbered list of what must be in the reply. Do not mention the budget.
```

## Follow-up prompts
- "Make a table template for comparing three vendor quotes."
- "Write a polite follow-up asking for missing details."

## What to check
- Attachments, deadlines, and contact are right before sending.
- No confidential client information beyond what the vendor needs.

## Common problems
| Problem | Fix |
|---|---|
| Vague scope | Paste the scope list and drawing numbers |
