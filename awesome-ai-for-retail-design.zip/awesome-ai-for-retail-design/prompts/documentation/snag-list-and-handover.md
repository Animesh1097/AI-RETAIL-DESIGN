# Snag list and handover

| | |
|---|---|
| **Goal** | Turn site notes into a clean snag list and handover checklist |
| **Stage** | Documentation |
| **Works with** | Any assistant |
| **Status** | Starter |

## You need
Site inspection notes, photo captions, and the contractor's scope.

## Prompt

```text
Turn the site notes below into a snag list. Table columns: ID, area, defect description, priority (critical / major / minor), responsible party, action required, target date, status.
Group by area (facade, entrance, floor, walls, ceiling, joinery, lighting, signage, fitting rooms, cash wrap). Mark any item that affects safety or opening as critical. Do not invent items. Add a column "photo ref" and use the references in my notes.

NOTES:
[paste notes]
```

## Follow-up prompts
- "Write a message to the contractor listing critical items to close before opening."
- "Create a handover checklist from this snag list: documents, warranties, manuals, keys, test certificates."

## What to check
- Each item matches what you saw on site.
- Safety items are raised promptly and tracked.

## Common problems
| Problem | Fix |
|---|---|
| Missing locations | Add area and drawing references to notes |
