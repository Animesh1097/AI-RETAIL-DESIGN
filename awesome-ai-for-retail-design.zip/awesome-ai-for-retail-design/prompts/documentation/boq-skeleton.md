# BOQ skeleton

| | |
|---|---|
| **Goal** | Create a structured BOQ with sections and line items, with quantities and rates left empty |
| **Stage** | Documentation |
| **Works with** | Any assistant, then a spreadsheet |
| **Status** | Starter |

## You need
Concept, material schedule, fixture list, and a list of drawings. Read [AI for documentation](../../guides/10-ai-for-documentation-boq-and-vendors.md).

## Prompt

```text
Create a BOQ skeleton for the fit-out of a [store type], [area] m², in [city]. Design summary: [materials, fixtures, lighting, services].
Sections: preliminaries, demolition and civil, flooring, wall finishes and partitions, ceiling, joinery and fixtures, glazing and doors, signage and graphics, electrical and lighting, HVAC, plumbing (if relevant), fire protection, loose furniture and equipment, testing and handover.
Return CSV with columns: section, item code, description, specification, unit, quantity, rate, amount, notes.
Rules: leave quantity and rate EMPTY. Do not invent numbers. Use units such as m², m, nos., lump sum. Flag items often forgotten in this type of project in notes.
```

## Follow-up prompts
- "Review this BOQ for missing items, duplicated items, and inconsistent units."
- "Write scope notes for the joinery section for a vendor."

## What to check
- Quantities from your drawings and takeoff, and rates from vendors, not AI.
- Items match the finish and fixture schedules.

## Common problems
| Problem | Fix |
|---|---|
| Filled-in numbers | Repeat "leave quantity and rate empty" |
| Inconsistent units | Ask for a units list and fix the spreadsheet |
