# Meeting minutes to actions

| | |
|---|---|
| **Goal** | Convert raw meeting notes into decisions and an action list |
| **Stage** | Documentation |
| **Works with** | Any assistant |
| **Status** | Starter |

## Prompt

```text
Convert the meeting notes below into: (1) a three-line summary, (2) decisions made, (3) open questions, (4) an action table with columns: action, owner, due date, dependency, status. If an owner or date is missing, write "TO CONFIRM". Do not add actions that aren't in the notes. Then draft a short email to send to all attendees.

NOTES:
[paste notes]
```

## What to check
- Owners and dates match what was said.
- Sensitive remarks are removed before sharing.

## Common problems
| Problem | Fix |
|---|---|
| Assigned owners incorrectly | Make the rule explicit: "only assign owners named in the notes" |
