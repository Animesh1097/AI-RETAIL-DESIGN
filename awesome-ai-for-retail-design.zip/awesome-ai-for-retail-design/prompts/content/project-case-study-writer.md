# Project case study writer

| | |
|---|---|
| **Goal** | Turn project notes into a clear case study for a portfolio or this repo |
| **Stage** | Content |
| **Works with** | Any assistant |
| **Status** | Starter |

## You need
Your notes: the brief, constraints, what you did, tools, results, and lessons. Remove confidential details unless you have permission.

## Prompt

```text
Write a case study from my notes in plain, specific language.
Structure: title; one-line summary; the brief and constraints; my approach step by step; where AI helped and where I did the work myself (be honest); key decisions and why; results (use only numbers I give; otherwise write "result not measured"); what didn't work; lessons; tools and prompts used.
Do not invent metrics, quotes, or client details. Label any AI-generated image.

NOTES:
[paste notes]
```

## Follow-up prompts
- "Make a 150-word version for LinkedIn."
- "List what evidence (images, drawings, before and after) I should add."

## What to check
- Every fact and number comes from your notes.
- Client permission and image rights are in place.

## Common problems
| Problem | Fix |
|---|---|
| Marketing fluff | Add "no superlatives, use concrete verbs" |
