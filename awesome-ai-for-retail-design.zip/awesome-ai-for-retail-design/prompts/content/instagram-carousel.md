# Instagram carousel

| | |
|---|---|
| **Goal** | Plan an 8-slide carousel that explains a project or an idea |
| **Stage** | Content |
| **Works with** | Any assistant; Canva or Figma for layout |
| **Status** | Starter |

## Prompt

```text
Plan an 8-slide Instagram carousel about [topic or project] for [audience: e.g. retail brand owners].
Slide 1: a hook of max 8 words. Slides 2 to 7: one idea each, a headline of max 8 words and body text of max 25 words, plus a visual suggestion. Slide 8: a summary and one call to action.
Also give a caption (max 60 words) and 8 hashtags. Use specific examples. No filler.
```

## What to check
- Facts and claims are correct, and images are yours or properly licensed.
- Text is readable on a phone.

## Common problems
| Problem | Fix |
|---|---|
| Slides too wordy | Lower the word limits |
