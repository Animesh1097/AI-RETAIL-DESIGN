# 30-second store reel

| | |
|---|---|
| **Goal** | Plan a 30-second reel shot by shot, in three 10-second parts |
| **Stage** | Content |
| **Works with** | Any assistant (script); Runway, Kling, Luma (clips); ElevenLabs (voice); CapCut (edit) |
| **Status** | Starter |

## You need
A project, three to five approved stills, and the brand's tone. Read [AI video for retail](../../guides/11-ai-video-for-retail.md).

## Prompt

```text
Write a 30-second Instagram Reel script for [brand or project], a [store type].
Goal: [e.g. show the process from brief to opening day].
Structure: three parts of 10 seconds each: hook, build, payoff.
For each part give: shot description, a 5 to 8 word on-screen text, one voiceover line (max 25 words), and an image-to-video prompt for the shot (one camera move, no people, no text).
Keep the same presenter style, tone, and music mood in all parts. Finish with a caption (max 40 words), a call to action, and 8 relevant hashtags.
```

## Follow-up prompts
- "Shorten the voiceover so each part fits comfortably in 10 seconds."
- "Give two alternative hooks for the first two seconds."

## What to check
- Voiceover timing and caption accuracy.
- Music, voice, and footage licences.

## Common problems
| Problem | Fix |
|---|---|
| Too much narration | Limit words per part, ask for pauses |
| Clips don't match | Use stills from one approved set as start frames |
