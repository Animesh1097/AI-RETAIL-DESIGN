# Prompt library

Copy-paste prompts for each stage of a retail project. Replace `[square brackets]` with your details.

## How to use a prompt

1. **Give context.** The more specific your inputs (store type, area, city, audience, budget, brand tone), the more useful the output.
2. **Run it, then follow up.** Every prompt page lists follow-up prompts. The first answer is a draft.
3. **Check the result.** Each page ends with what to verify.
4. **Log what works.** Use the [prompt log template](../templates/prompt-log-template.csv).

## Status labels

| Label | Meaning |
|---|---|
| **Starter** | Written from design experience. Not yet field-tested on a real project in every tool. |
| **Field-tested** | Run on a real project, with notes on what to adjust. Set by contributors who used it. |

## Index

### Discovery
- [Client discovery questions](discovery/client-discovery-questions.md)
- [Brief to design brief](discovery/brief-to-design-brief.md)
- [Competitor store audit](discovery/competitor-store-audit.md)
- [Customer journey map](discovery/customer-journey-map.md)

### Concept
- [Concept mood board](concept/concept-moodboard.md)
- [Concept narrative](concept/concept-narrative.md)
- [Brand guidelines to store brief](concept/brand-guidelines-to-store-brief.md)

### Planning
- [Zoning and flow options](planning/zoning-and-flow-options.md)
- [Fixture schedule](planning/fixture-schedule.md)
- [Materials and finishes](planning/materials-finishes.md)
- [Lighting concept](planning/lighting-concept.md)

### Visualisation
- [Sketch to render](visualisation/sketch-to-render.md)
- [Facade and entrance](visualisation/facade-and-entrance.md)
- [Render revision and inpainting](visualisation/render-revision-inpainting.md)
- [Consistent multi-view set](visualisation/consistent-multi-view.md)

### Merchandising
- [Window display](merchandising/window-display.md)
- [Planogram brief](merchandising/planogram-brief.md)
- [Seasonal VM calendar](merchandising/seasonal-vm-calendar.md)
- [Product display backgrounds](merchandising/product-display-backgrounds.md)
- [Signage and wayfinding](merchandising/signage-and-wayfinding.md)

### Documentation
- [BOQ skeleton](documentation/boq-skeleton.md)
- [Vendor RFQ email](documentation/vendor-rfq-email.md)
- [Snag list and handover](documentation/snag-list-and-handover.md)
- [Meeting minutes to actions](documentation/meeting-minutes-to-actions.md)

### Content
- [Reel script](content/reel-script.md)
- [Project case study writer](content/project-case-study-writer.md)
- [Instagram carousel](content/instagram-carousel.md)

Template for new prompts: [_TEMPLATE.md](_TEMPLATE.md)
