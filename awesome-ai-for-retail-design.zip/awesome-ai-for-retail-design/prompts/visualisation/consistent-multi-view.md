# Consistent multi-view set

| | |
|---|---|
| **Goal** | Create several views that clearly show the same store |
| **Stage** | Visualisation |
| **Works with** | Any image tool; a vision-capable assistant for step 1 |
| **Status** | Starter |

## You need
One approved render or 3D model view. Read [Keeping renders consistent](../../guides/09-keeping-renders-consistent.md).

## Step 1: Turn an approved image into a spec block (assistant)

```text
Look at this approved store render. Write a "store spec" I can paste into every image prompt: floor, wall, ceiling, fixture materials and colours, palette, lighting type and temperature, fixture shapes, and overall mood. Use precise material words. Do not describe the camera or the layout.
```

## Step 2: Generate each view

```text
[paste store spec]
VIEW: [eye-level from the entrance towards the feature wall, 24 mm].
Keep the same materials and lighting as the reference image. No people, no text.
```

Repeat with: facade at dusk, detail of the display, cash wrap, fitting or experience area.

## Follow-up prompts
- "Compare these images and list inconsistencies in floor, ceiling, fixtures, or lighting."

## What to check
- Use the [consistency checklist](../../guides/09-keeping-renders-consistent.md#consistency-checklist).
- Colour-correct the set in an editor.

## Common problems
| Problem | Fix |
|---|---|
| Floor changes between views | Repeat material words exactly, use a style reference |
| Fixtures change shape | Describe fixture geometry in the spec block, inpaint when needed |
