# Facade and entrance

| | |
|---|---|
| **Goal** | Explore the street-facing look: facade, window, entrance, and signage zone |
| **Stage** | Visualisation |
| **Works with** | Midjourney, Firefly, ChatGPT or Gemini images, mnml.ai |
| **Status** | Starter |

## You need
Frontage width, building context, signage rules from the landlord, and concept materials.

## Prompt

```text
Street-level view of a [store type] shopfront, [frontage] m wide, in a [high street / mall / market lane] in [city]. Concept: [style]. Facade materials: [list]. Large display window with [window idea]. Entrance with [door type] at [position]. Signage: [type and position, no text]. Dusk, warm interior glow, soft street light. Wide-angle, slightly raised pedestrian viewpoint, architectural photograph, no people, no readable text.
```

## Variations
- Day version: "bright overcast daylight".
- Night version: "evening, illuminated signage and window lighting".
- Mall unit: "inside a shopping mall, mall floor visible, neighbouring units as plain shutters".

## Follow-up prompts
- "Same facade with a seasonal window display of [concept]."
- "Three alternative signage positions, keep everything else fixed."

## What to check
- Frontage proportions, signage size, and landlord rules.
- Real signage text and logo added in an editor.

## Common problems
| Problem | Fix |
|---|---|
| Door looks too small or large | State "standard door height" and include a person-sized object for scale |
| Signs have gibberish text | Prompt "blank sign panel" and add text later |
