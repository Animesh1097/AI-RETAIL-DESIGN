# Render revision and inpainting

| | |
|---|---|
| **Goal** | Change one thing in an approved render without changing the rest |
| **Stage** | Visualisation |
| **Works with** | Photoshop Generative Fill, mnml.ai masking, ComfyUI inpainting, Midjourney editor |
| **Status** | Starter |

## You need
An approved image and a mask over the area to change.

## Prompt

```text
Replace the selected area with [new element: e.g. a pale oak display table with rounded corners and three folded sweaters].
Match the existing perspective, lighting direction, colour temperature, and shadows.
Keep everything outside the selection unchanged.
```

## Revision patterns

| Change | Prompt idea |
|---|---|
| Swap a material | "Change the floor to honed limestone, keep joints and reflections realistic" |
| Remove an object | "Remove the object and fill with matching wall and floor" |
| Add signage zone | "Add a blank illuminated sign panel, no text" |
| Fix fixtures | "Make the shelf brackets visible and attached to the wall" |
| Change colour | "Change the wall to sage green plaster, keep texture and light" |

## Follow-up prompts
- "Make the change a little less bright" (small refinements rather than regenerating).

## What to check
- Edges blend, shadows match, and nothing else shifted.
- Save the original and the revision together.

## Common problems
| Problem | Fix |
|---|---|
| Visible seam | Widen the mask slightly and ask for blending |
| Lighting mismatch | Name the light direction in the prompt |
