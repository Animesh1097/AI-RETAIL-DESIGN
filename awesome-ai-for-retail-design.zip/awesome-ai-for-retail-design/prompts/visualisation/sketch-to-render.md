# Sketch to render

| | |
|---|---|
| **Goal** | Turn a line sketch or 3D screenshot into a realistic render that keeps the layout |
| **Stage** | Visualisation |
| **Works with** | Veras, mnml.ai, ComfyUI, Krea, Midjourney with an image reference |
| **Status** | Starter |

## You need
A clean sketch or screenshot (one camera view, simple geometry), plus the spec block of materials, palette, and lighting.

## Prompt

```text
Photorealistic interior render of a [store type].
Keep the exact layout, proportions, and camera angle of the reference image.
Materials: floor [..], walls [..], fixtures [..], ceiling [..].
Palette: [..]. Lighting: [..].
Style: [..].
No people, no text, no logos, no extra furniture.
```

## Tool notes

| Tool | What to adjust |
|---|---|
| Veras | Raise geometry strength to keep layout; put materials and lighting in the prompt |
| mnml.ai | Use sketch-to-render, then mask and fix local areas |
| ComfyUI | Depth or edge control strength about 0.6 to 0.9, see the [guide](../../guides/08-sketch-to-render-with-comfyui.md) |
| Midjourney | Use the image as a reference and state "keep composition", then check drift |

## Follow-up prompts
- "Same view, evening lighting, warmer mood."
- "Same view, change the floor to [material], keep everything else the same."

## What to check
- Overlay on the source. Did a counter, door, or column move?
- Scale and buildability using the [QA checklist](../../templates/render-qa-checklist.md).

## Common problems
| Problem | Fix |
|---|---|
| Layout drifts | Increase structure control, simplify source |
| Extra objects | Add "no extra furniture", remove unneeded words |
| Plastic look | Specify real finishes and a touch of wear |
