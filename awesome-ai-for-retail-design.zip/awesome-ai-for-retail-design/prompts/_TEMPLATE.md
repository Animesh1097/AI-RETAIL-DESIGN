# Prompt name

| | |
|---|---|
| **Goal** | One line on what this helps you do |
| **Stage** | Discovery / Concept / Planning / Visualisation / Merchandising / Documentation / Content |
| **Works with** | Tools you have used it with |
| **Status** | Starter / Field-tested |

## You need
Inputs the user should have ready.

## Prompt

```text
Prompt text with [variables].
```

## Filled-in example
A realistic input, and a description of the kind of output you got.

## Follow-up prompts
- A refinement
- A second refinement

## What to check
- Accuracy, rights, scale, spelling, brand fit

## Common problems
| Problem | Fix |
|---|---|

**Contributed by:** name or handle · **Tool and version:** · **Date tested:**
