# Lighting concept

| | |
|---|---|
| **Goal** | Draft a layered lighting concept to discuss with a lighting designer |
| **Stage** | Planning |
| **Works with** | Any assistant |
| **Status** | Starter |

## You need
Concept, materials, store zones, ceiling height, and daylight conditions. Read [Retail lighting](../../guides/04-retail-lighting.md).

## Prompt

```text
Write a lighting concept for a [store type] with this concept: [style and materials], ceiling height [m], daylight: [windows description].
Structure: (1) overall idea in three sentences, (2) layers: ambient, accent, task, decorative, (3) for each zone (facade and window, entrance, feature wall, shelving, central displays, fitting rooms, cash wrap) the effect wanted, fixture types, and mood, (4) target colour temperature and colour-rendering requirements to validate, (5) control scenes (opening, daytime, evening), (6) risks (glare, reflections, heat), (7) questions for the lighting designer.
Treat all numbers as targets to validate with calculations. Do not claim compliance.
```

## Follow-up prompts
- "Turn the zone effects into a render prompt for the main view."
- "List lighting items to add to the BOQ."

## What to check
- A lighting designer verifies levels, fixtures, and codes.
- Render lighting is a mood study, not a calculation.

## Common problems
| Problem | Fix |
|---|---|
| Only mood words | Ask for fixture types and control scenes |
