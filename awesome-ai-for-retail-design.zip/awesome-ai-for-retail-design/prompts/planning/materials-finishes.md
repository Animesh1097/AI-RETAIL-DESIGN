# Materials and finishes shortlist

| | |
|---|---|
| **Goal** | Build a first shortlist of materials by zone to discuss with suppliers |
| **Stage** | Planning |
| **Works with** | Any assistant |
| **Status** | Starter |

## You need
Store type, area, city, style, budget level, and any must-haves. Read [Materials and finishes](../../guides/05-materials-and-finishes.md).

## Prompt

```text
Act as a retail interior designer. Project: [store type], [area] m², [city], concept [style], budget [low / mid / high].
For each zone (floor, walls, ceiling, main fixtures, display plinths, cash wrap, fitting rooms, entrance) propose 2 options.
Return a table: zone, material, finish, why it fits the concept, durability and maintenance notes, indicative cost tier (low / mid / high), risks, and one alternative.
Prefer materials commonly available in [country or region]. Finish with 10 questions to ask suppliers (lead time, samples, fire and slip ratings, warranty, repair).
Do not state prices or technical ratings as fact. Write "verify with supplier" instead.
```

## Filled-in example
Café with retail corner, 80 m², mid budget, calm and warm. Expect options such as terrazzo or large-format tile floors, oak veneer or ribbed panels, with notes on cleaning and heat marks.

## Follow-up prompts
- "Reduce this to one preferred option per zone with a combined palette description for image prompts."
- "Which choices are the highest risk for delay or cost?"

## What to check
- Fire, slip, and emissions ratings, availability, and prices are confirmed with suppliers and samples.

## Common problems
| Problem | Fix |
|---|---|
| Materials not available locally | Name the region and ask for local equivalents |
| Looks inconsistent | Ask for a "palette summary with a maximum of five materials" |
