# Fixture schedule

| | |
|---|---|
| **Goal** | Draft a fixture list with quantities logic and display capacity |
| **Stage** | Planning |
| **Works with** | Any assistant, then a spreadsheet |
| **Status** | Starter |

## You need
Range by category, units to display, store area, and concept direction.

## Prompt

```text
Create a fixture schedule for a [store type] of [area] m² with this range: [categories and approximate number of SKUs each]. Concept: [style and materials].
Return a table with columns: fixture code, name, type (wall, floor, table, case, window), category it serves, display method (hanging, folded, shelved, boxed), suggested size ranges (placeholders I will confirm), approximate display capacity logic, finish, special features (lighting, locks, power), priority (must / nice).
Add a short list of the fixtures most often forgotten in this type of store.
Do not invent quantities. Where a quantity depends on measured space, write "TO CALCULATE" and explain the logic.
```

## Follow-up prompts
- "Convert this to CSV with one row per fixture."
- "Suggest a smaller set that works for a 40 m² pop-up."

## What to check
- Sizes and quantities come from your layout and product dimensions.
- Fixture lists match the BOQ and finish schedule.

## Common problems
| Problem | Fix |
|---|---|
| Invented quantities | Repeat "TO CALCULATE" rule |
| Missing practical items | Ask for stools, mirrors, bins, shopping baskets, stockroom shelving |
