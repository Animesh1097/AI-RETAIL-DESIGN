# Zoning and flow options

| | |
|---|---|
| **Goal** | Build a space programme, an adjacency list, and 3 to 5 zoning options as text |
| **Stage** | Planning |
| **Works with** | Any assistant |
| **Status** | Starter |

## You need
Store type, area, frontage and depth, entrance position, fixed elements (columns, services), range, and operations needs. Use the plan description format in the [planning guide](../../guides/02-store-planning-and-customer-flow.md#using-ai-for-planning).

## Prompt

```text
You are a retail store planner. Project: [store type], [area] m², frontage [x] m, depth [y] m, entrance at [position]. Fixed elements: [list]. Range: [categories]. Services: [fitting rooms / demo / consultation / café]. Staff on shop floor: [number].
1. Create a space programme: zones with a target share of floor area, and what each zone must do.
2. Create an adjacency list: which zones must be close, which should be apart, and why.
3. Propose [3] zoning options in plain text (describe positions relative to the entrance, left and right, front and back). Name each option by its idea.
4. For each option give: customer flow, sightlines from the entrance and cash wrap, strengths, risks, and the first thing to test.
5. List the assumptions you made and the facts you still need.
Do not give exact dimensions. I will draw and measure.
```

## Filled-in example
Input: 120 m² fashion store, 8 m frontage, 15 m depth, entrance left of centre, two columns at 6 m. Expect options such as loop, spine, and free-flow, each with notes on where to put the hero zone, fitting rooms, and cash wrap.

## Follow-up prompts
- "Score these options with the layout matrix in the guide and explain each score."
- "Which option is most flexible for seasonal change?"
- "What could go wrong with staff supervision in option B?"

## What to check
- Options respect the fixed elements and the entrance.
- You draw each option with real dimensions before choosing.
- Codes for egress, fire, and accessibility are checked by a qualified person.

## Common problems
| Problem | Fix |
|---|---|
| Options all similar | Ask for "three structurally different ideas" |
| Generic advice | Add range, services, and staff numbers |
