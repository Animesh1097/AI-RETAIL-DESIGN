# Seasonal VM calendar

| | |
|---|---|
| **Goal** | Build a 12-month plan of VM themes, props, and lead times |
| **Stage** | Merchandising |
| **Works with** | Any assistant, then Notion, Sheets, or Airtable |
| **Status** | Starter |

## You need
Store type, country or region, and the retail calendar (launches, sales).

## Prompt

```text
Create a 12-month visual merchandising calendar for a [store type] in [country/region], starting [month].
Columns: month, key retail moments, regional or cultural events (mark dates as "verify"), theme, hero display idea, window idea, colour palette, props to source, graphics to produce, order-by date (assuming [4] weeks lead time), and install week.
Include two quiet periods for maintenance and photography.
```

## Follow-up prompts
- "Turn this into a CSV I can import into Airtable."
- "Add a column for budget tier (low / mid / high) and reuse notes."

## What to check
- Verify festival and event dates for your region. AI can get dates wrong.
- Check lead times with your suppliers.

## Common problems
| Problem | Fix |
|---|---|
| Generic themes | Add brand tone and customer interests |
