# Signage and wayfinding

| | |
|---|---|
| **Goal** | Plan a signage hierarchy, write short copy, and mock up options |
| **Stage** | Merchandising |
| **Works with** | Any assistant (copy and plan); Ideogram, Midjourney, Canva (mockups) |
| **Status** | Starter |

## You need
Store layout, zones, offers, languages, and brand tone.

## Step 1: Hierarchy and copy

```text
Plan the signage for a [store type] with these zones: [list]. Languages: [list].
1. Propose a three-level hierarchy: orientation signs (category), feature signs (offers), product and price signs.
2. For each level, give placement, suggested reading distance, and the maximum word count.
3. Write 10 options of up to 6 words for [signage type: window decal, shelf talker, entrance sign] with the offer: [offer]. Tone: [tone]. No clichés, no exclamation marks.
```

## Step 2: Mockup

```text
Mockup of a [signage type] for a [store type], reading "[exact text]", in [font style], colours [palette], on [surface], realistic photo, front view.
```

## Size rule of thumb
A common guideline is about 25 mm of letter height for every 3 m of viewing distance (1 in per 10 ft). Confirm with the fabricator and local signage rules.

## What to check
- Every letter. AI often misspells words in images.
- Rebuild the final artwork as a vector file with real fonts.
- Contrast and legibility from the real viewing distance.

## Common problems
| Problem | Fix |
|---|---|
| Garbled text in mockup | Ask for a blank panel and add type in an editor |
| Too many words | Set a maximum word count |
