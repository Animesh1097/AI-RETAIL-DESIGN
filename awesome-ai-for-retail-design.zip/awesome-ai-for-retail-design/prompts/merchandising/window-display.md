# Window display concepts

| | |
|---|---|
| **Goal** | Get 5 window concepts with prop lists, check feasibility, then visualise the best |
| **Stage** | Merchandising |
| **Works with** | Any assistant (steps 1 and 3), any image tool (step 2) |
| **Status** | Starter |

## You need
Window size and depth, hanging points, season or campaign, budget level, and hero products. Read [VM principles](../../guides/03-visual-merchandising-principles.md).

## Step 1: Concepts and props

```text
You are a visual merchandiser. Create 5 window display concepts for a [store type] for [season or campaign].
Window: about [width x height x depth], [open back / closed back], hanging points [yes/no]. Budget: [low / mid / high]. Brand tone: [adjectives]. Hero products: [list].
For each concept give: a name, a one-sentence idea, how the hero product is shown, prop list, colour palette, lighting note, graphics or signage, installation effort (easy / medium / hard), and reuse potential after the campaign.
Design for a glance from across the street: one idea per window. Prefer reusable and locally sourced props.
```

## Step 2: Visual

```text
Retail shop window display, [concept description], hero product: [product], props: [list], palette: [colours], evening lighting with spot accents, seen from the pavement at eye level, realistic photograph, no text.
```

## Step 3: Feasibility check

```text
Review this window concept for installation problems: [paste concept]. List risks (weight, hanging, glare, dust, fire safety, access) and a one-page install plan with time estimates for two people.
```

## What to check
- It fits the real window and can be built with your props and budget.
- Day and night views both work.

## Common problems
| Problem | Fix |
|---|---|
| Overcrowded concept | Ask for "maximum five elements" |
| Unbuildable ideas | Add the real depth, hanging points, and budget |
