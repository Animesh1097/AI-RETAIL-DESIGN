# Planogram brief

| | |
|---|---|
| **Goal** | Draft shelf-layout rules and a facings table for a category |
| **Stage** | Merchandising |
| **Works with** | Any assistant, then a spreadsheet or planogram tool |
| **Status** | Starter |

## You need
Product list with dimensions, shelf width and height, category strategy (best sellers, margin, new lines).

## Prompt

```text
Draft a planogram brief for the [category] section in a [store type]. Fixture: [number] shelves, each [width] mm wide and [height] mm usable height, [number] bays.
Products (name, width mm, height mm, role: hero / core / filler): [paste table].
1. Propose the blocking logic (by brand, use, price, or customer need) and explain why.
2. Suggest shelf placement by role: eye level, hand level, top and bottom.
3. Return a table: shelf, product, facings, notes. Check that widths fit; flag any item that doesn't.
4. List rules for staff to maintain it (replenishment, price tags, gaps).
Show your width calculations so I can verify them.
```

## Follow-up prompts
- "Make a version for a bay half this width."
- "Give three display variations for a promotion without changing the blocks."

## What to check
- Re-calculate every width yourself. Language models make arithmetic errors.
- Real stock and shelf dimensions decide the final plan.

## Common problems
| Problem | Fix |
|---|---|
| Widths don't add up | Ask for step-by-step totals, or do the sums in a spreadsheet |
