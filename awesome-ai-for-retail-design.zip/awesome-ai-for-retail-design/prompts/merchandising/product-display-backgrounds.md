# Product display backgrounds

| | |
|---|---|
| **Goal** | Create lifestyle backgrounds for product shots used in displays and social posts |
| **Stage** | Merchandising |
| **Works with** | Photoroom, Pebblely, Flair, Photoshop Generative Fill |
| **Status** | Starter |

## You need
A clean photo of the real product on a plain background.

## Prompt

```text
[Product] on [surface: e.g. marble counter, walnut shelf], [setting: e.g. bright boutique interior, sunlit window sill], soft natural light from the left, shallow depth of field, [1 or 2 props], clean premium look, no text.
```

## Variations
- Seasonal: "festive ... with warm lights", "monsoon ... with soft rain light".
- Display mockup: "placed on a retail display plinth in a store, blurred shelves behind".

## What to check
- The product's shape, colour, labels, and logo match the real item exactly.
- Shadows and reflections match the light direction.
- Remove invented text or branding in the background.

## Common problems
| Problem | Fix |
|---|---|
| Product altered | Generate only the background and composite the original cutout |
| Floating product | Add "resting on the surface with a soft contact shadow" |
