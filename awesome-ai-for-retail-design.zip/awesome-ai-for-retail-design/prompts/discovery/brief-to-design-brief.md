# Brief to design brief

| | |
|---|---|
| **Goal** | Turn messy client notes into a structured design brief and a list of open questions |
| **Stage** | Discovery |
| **Works with** | Claude, ChatGPT, Gemini |
| **Status** | Starter |

## You need
Meeting notes, emails, or a client's rough brief. Remove confidential names if your tool or contract requires it.

## Prompt

```text
Turn the notes below into a design brief for a retail project.
Sections: project overview, objectives, target customer, brand personality, product range, space details, must-haves, constraints (budget, timeline, location, approvals), references mentioned, deliverables, success criteria.
Rules: use only what the notes say. Mark anything missing or unclear as "TO CONFIRM". Then list the 10 most important questions to ask the client, ordered by risk.

NOTES:
[paste notes here]
```

## Follow-up prompts
- "Rewrite as a one-page brief a contractor can follow, with only build-relevant items."
- "Draft a short email to the client confirming this brief and asking the open questions."

## What to check
- Nothing was invented. Compare against your notes line by line.
- Budget and dates match what the client said.

## Common problems
| Problem | Fix |
|---|---|
| AI adds plausible but invented details | Repeat "use only what the notes say" and ask it to quote the line that supports each claim |
| Brief too long | Ask for a one-page version |
