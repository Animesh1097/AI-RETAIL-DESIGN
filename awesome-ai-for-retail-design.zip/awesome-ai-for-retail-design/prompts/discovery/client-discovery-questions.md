# Client discovery questions

| | |
|---|---|
| **Goal** | Get a tailored question list for the first client meeting |
| **Stage** | Discovery |
| **Works with** | Any assistant |
| **Status** | Starter |

## You need
A two-line project summary. For the full standard list use the [client questionnaire template](../../templates/client-questionnaire.md).

## Prompt

```text
You are a senior retail design consultant. I am meeting a client about a new [store type] in [city or mall/street]. Summary: [two lines: brand, product range, size, timeline].
Write the questions I should ask, grouped under: business goals, customers, product and range, brand, space and site, operations and staffing, budget and timeline, constraints and approvals, success measures.
Mark the 10 most important questions for a first 45-minute meeting. For each of those, add one line explaining why it matters. Keep wording plain, not jargon.
```

## Filled-in example
Input: a skincare brand opening a 60 m² mall unit in three months. Expect questions about target customer, services offered (consultation, sampling), product volume, mall design rules, budget range, staffing, and how they'll judge success.

## Follow-up prompts
- "Turn the top 10 into a one-page email I can send before the meeting."
- "Which questions will reveal hidden risks (landlord rules, lead times, approvals)?"

## What to check
- Remove questions the client already answered in writing.
- Add site-specific questions you only learn by visiting.

## Common problems
| Problem | Fix |
|---|---|
| List is too generic | Add product types, brand tone, and constraints to the summary |
| Too many questions | Ask for "top 10 only" |
