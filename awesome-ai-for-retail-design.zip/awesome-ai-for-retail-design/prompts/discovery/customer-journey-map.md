# Customer journey map

| | |
|---|---|
| **Goal** | Map the in-store experience and find design opportunities |
| **Stage** | Discovery |
| **Works with** | Any assistant |
| **Status** | Starter |

## You need
Target customer description, store type, and the main goals of the visit.

## Prompt

```text
Create an in-store customer journey map for [customer type] visiting a [store type].
Stages: approach, threshold, orientation, discovery, engagement, trial, purchase, exit.
Return a table with: what the customer does, what they think and feel, touchpoints in the store, likely pain points, and design opportunities.
Finish with the 5 most important moments to get right and why. Label any assumption.
```

## Filled-in example
A first-time buyer in a consumer electronics store: expect pain points around not knowing where to start, too many similar products, and long waits for demo help.

## Follow-up prompts
- "Suggest layout and VM moves for each pain point."
- "Which stages should staff handle versus signage?"

## What to check
- Validate with real customer observation or interviews. This is a hypothesis.

## Common problems
| Problem | Fix |
|---|---|
| Too generic | Specify purchase type (gift vs. self-purchase) and context |
