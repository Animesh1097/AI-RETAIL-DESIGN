# Competitor store audit

| | |
|---|---|
| **Goal** | Turn your store-visit notes into a comparison and clear takeaways |
| **Stage** | Discovery |
| **Works with** | Any assistant (with photos if supported) |
| **Status** | Starter |

## You need
Notes or photos from **real visits**. Do not ask AI to describe competitor stores from memory. It may invent details.

## Prompt

```text
I visited these [number] stores: [names and locations]. Below are my notes per store.
Create a comparison table with rows for: facade and window, entrance, layout and flow, hero displays, fixtures and materials, lighting, signage, staff and service, price display, customer behaviour I saw.
Then give: (1) three things worth learning from, (2) three things to avoid, (3) gaps no competitor fills, (4) how our client could differ. Base everything only on my notes.

NOTES:
[paste notes per store]
```

## Follow-up prompts
- "Turn the gaps into three concept directions."
- "Make a one-slide summary for the client."

## What to check
- Each claim is in your notes. Ask "which note supports this?"
- Photos are your own, and you have permission for any shared images.

## Common problems
| Problem | Fix |
|---|---|
| Generic conclusions | Add customer observations (what people did, where they paused) |
