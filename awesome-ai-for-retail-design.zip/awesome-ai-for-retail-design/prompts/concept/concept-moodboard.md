# Concept mood board

| | |
|---|---|
| **Goal** | Explore 4 to 6 distinct store concept directions |
| **Stage** | Concept |
| **Works with** | Midjourney, Firefly, Krea, Leonardo, ChatGPT or Gemini images |
| **Status** | Starter |

## You need
Store type, location, a few brand words, and two or three materials or colours that matter.

## Prompt

```text
Interior of a [store type] store, [city] flagship, [style: e.g. warm minimalism, Indian contemporary, industrial luxe].
Key materials: [e.g. fluted oak, brushed brass, terrazzo].
Colour palette: [3 to 4 colours].
Lighting: [e.g. warm track lighting, soft cove lighting].
Layout cues: [e.g. central display island, feature back wall, wide entry].
Wide-angle eye-level architectural photograph, realistic proportions, no people, no text.
```

## Filled-in example
Jewellery boutique, Jaipur flagship, warm minimalism with Rajasthani craft. Materials: sandstone, brass inlay, walnut. Palette: sand, deep green, brass, ivory. Lighting: warm spots on glass displays. Layout: central island, arched back wall.

## Follow-up prompts
- Change only the **style line** four times to get four directions.
- "Same space, but evening lighting and a more dramatic mood."
- Use your favourite result as a style reference and generate the entrance, detail, and cash wrap views.

## What to check
- No impossible structures or unreadable text.
- Label AI images in the board.

## Common problems
| Problem | Fix |
|---|---|
| All four look the same | Make style lines more different, add contrasting materials |
| Generic "luxury" look | Name specific materials and one unexpected element |
| Wrong proportions | Add "realistic proportions, standard door height" |
