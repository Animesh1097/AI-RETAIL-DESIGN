# Brand guidelines to store design brief

| | |
|---|---|
| **Goal** | Translate brand guidelines into a one-page brief for a physical space |
| **Stage** | Concept |
| **Works with** | Claude, ChatGPT, Gemini (paste text or upload) |
| **Status** | Starter |

## Prompt

```text
Read the brand guidelines below and write a one-page store design brief.
Include: brand essence (2 sentences), colour and material direction, lighting mood, typography use in signage, do and don't rules, VM principles, customer experience goals.
Then list everything the guidelines do not cover that a store designer must decide (e.g. flooring, scale of logo, fixture style).
Quote the guideline line for each rule you include.

[paste guidelines]
```

## Follow-up prompts
- "Write a version for the contractor with build-relevant rules only."
- "Turn the do and don't rules into a VM checklist."

## What to check
- Compare with the original document. Ask the brand team about gaps.

## Common problems
| Problem | Fix |
|---|---|
| Rules invented for a physical store | Ask for "only rules stated in the document" |
