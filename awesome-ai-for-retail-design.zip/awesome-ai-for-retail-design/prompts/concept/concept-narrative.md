# Concept narrative

| | |
|---|---|
| **Goal** | Turn a chosen direction into a clear concept statement and design pillars |
| **Stage** | Concept |
| **Works with** | Any assistant |
| **Status** | Starter |

## You need
Brief, chosen mood images (described in words), and brand values.

## Prompt

```text
Write the concept narrative for a [store type] for [brand]. Brief: [summary]. Chosen direction: [describe materials, mood, palette, features].
Return:
1. A concept statement of 60 to 80 words in plain, specific language (no clichés such as "seamless", "curated experience").
2. Three design pillars, each with one sentence and one visible design move that proves it.
3. Names for the main zones (entrance, feature wall, core range, service, cash wrap).
4. Five taglines for internal use.
5. Three things this concept deliberately avoids.
```

## Follow-up prompts
- "Rewrite the statement for the client's CEO in 40 words."
- "Turn the pillars into a checklist I can use to review the final design."

## What to check
- Each pillar has a visible design move, not just an adjective.
- Language matches what you can build and the brand's tone.

## Common problems
| Problem | Fix |
|---|---|
| Vague, flowery text | Add "use concrete nouns and verbs, no abstract adjectives" |
