# Project title

**Type:** store / window / brand / campaign · **Year:** · **Your role:** · **Client permission to share:** yes / no

## The brief
What was needed, for whom, and the constraints.

## The workflow
| Step | Tool | What it produced | Time |
|---|---|---|---|
| | | | |

## Where AI helped
Be specific.

## Where it did not help, and what you did by hand

## Before and after
Add images. Label every AI-generated image.

## Key decisions and why

## Results
Only numbers you measured. Otherwise write "not measured".

## Lessons
What you would do differently.

## Prompts and tools used
Link to the prompts in this repo and note the tool versions.

**Contributed by:** name or handle · **Date:**
