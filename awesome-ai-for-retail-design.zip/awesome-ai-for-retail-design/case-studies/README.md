# Case studies

Real projects where AI helped a retail design workflow. This section stays empty until there are real examples, because invented case studies would defeat the purpose of this repo.

## What a good case study shows

- The brief and the constraints (time, budget, team size)
- What you did with AI, step by step, and what you did by hand
- Before and after visuals, with AI images labelled
- What didn't work, and what you would change
- Time or cost effects, only if you measured them
- The prompts and tools used, linked to this repo

## How to contribute

1. Copy the [template](_TEMPLATE.md) into a new file named like `jaipur-jewellery-boutique-concept.md`.
2. Remove client names and confidential details unless you have written permission.
3. Open a pull request. You can also use the [prompt writer](../prompts/content/project-case-study-writer.md) to draft it from your notes.

## Index

*No case studies yet. Yours could be the first.*
